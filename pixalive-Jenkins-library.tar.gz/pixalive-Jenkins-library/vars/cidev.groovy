//def call() {
//    pipeline {
//        agent any
//
//        environment {
//            AWS_ACCOUNT_ID = credentials('aws-account-id')
//            REGION = "ap-south-1"
//            REGISTRY = "${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${APP_NAME}"
//        }
//
//        stages {
//            stage('Git Pull') {
//                steps {
//                    script {
//                        // Clean workspace and clone the repository
//                        cleanWs()
//                        git credentialsId: 'pixalive-github', branch: 'main', url: "https://github.com/Tripalive/${APP_NAME}.git"
//                        sh 'env'
//                    }
//                }
//            }
//
//
//            stage('Build and Test') {
//                steps {         
//                  sh 'npm install pm2'
//                  sh 'npm install'
//                  sh 'npm install axios'
//
//                }
//            }
//
//            stage('Static Code Analysis') {   
//                steps {
//                  withCredentials([string(credentialsId: 'sonarqubetoken', variable: 'SONAR_AUTH_TOKEN')]) {
//                  sh "/opt/sonar-scanner/bin/sonar-scanner -Dsonar.login=$SONAR_AUTH_TOKEN -Dsonar.host.url=http://13.235.0.121:9000 -Dsonar.projectKey=${APP_NAME} -Dsonar.qualitygate.wait=true"
//                }
//              }
//            }
//
//
//            stage('Docker Build') {
//                steps {
//                    script {
//                        sh "docker build -t ${APP_NAME}:${VERSION} ."
//                    }
//                }
//            }
//
//            stage('Image Push to ECR') {
//                steps {
//                    script {
//                        withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: 'aws-credentials']]) {
//                            sh """
//                                aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com
//                                docker tag ${APP_NAME}:${VERSION} ${REGISTRY}:${VERSION}
//                                docker push ${REGISTRY}:${VERSION}
//                            """
//                        }
//                    }
//                }
//            }
//        }
//    }
//}

def call() {
    pipeline {
        agent any

        environment {
            AWS_ACCOUNT_ID = credentials('aws-account-id')
            REGION = "ap-south-1"
            REGISTRY = "${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${APP_NAME}"
            IMAGE_TAG = "${APP_VERSION}-${BUILD_NUMBER}"
            JENKINS_API_TOKEN = credentials("JENKINS_API_TOKEN")
        }

        stages {


            stage('Git Pull') {
                steps {
                    script {
                        // Clean workspace and clone the repository
                        cleanWs()
                        git credentialsId: 'pixalive-github', branch: 'development', url: "https://github.com/Tripalive/${APP_NAME}.git"
                        sh 'env'
                        echo "Debug: Completed git pull stage"
                    }
                }
            }




            stage('Build and Test') {
                steps {
                  sh 'npm install pm2'
                  sh 'npm install'
                  sh 'npm install axios'

                }
            }

//            stage('Static Code Analysis') {
//                steps {
//                  withCredentials([string(credentialsId: 'sonarqubetoken', variable: 'SONAR_AUTH_TOKEN')]) {
//                  sh "/opt/sonar-scanner/bin/sonar-scanner -Dsonar.login=$SONAR_AUTH_TOKEN -Dsonar.host.url=http://13.201.7.245:9000 -Dsonar.projectKey=${APP_NAME} -Dsonar.qualitygate.wait=true"
//                }
//              }
//            }


            stage('Docker Build') {
                steps {
                    script {
                        sh "docker build -t ${APP_NAME}:${APP_VERSION} ."
                    }
                }
            }

            stage('Image Push to ECR') {
                steps {
                    script {
                        withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: 'aws-credentials']]) {
                            sh """
                                aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com
                                docker tag ${APP_NAME}:${APP_VERSION} ${REGISTRY}:${IMAGE_TAG}
                                docker push ${REGISTRY}:${IMAGE_TAG}
                            """
                        }
                    }
                }
            }
           


            stage('Trigger Deploy pipeline') {

                steps {
                    echo "Debug: Triggering CD pipeline with IMAGE_TAG=${IMAGE_TAG}"
                    build job: "pixalivecd/${APP_NAME}-cd/development", parameters: [
                        string(name: 'IMAGE_TAG', value: "${IMAGE_TAG}")
                    ], wait: false
                }
            }
        } 
        
	post {
            success {
                mail bcc: '', body: "Job success - ${JOB_BASE_NAME}\nJenkins URL - ${JOB_URL}", cc: 'rajasekar@pixalive.me,murugan@upturntechnology.com', from: 'kiran@pixalive.me', replyTo: '', subject: "The Pipeline success - ${JOB_NAME}", to: 'kabeer@pixalive.me,kiran@pixalive.me'
            }
            failure {
                mail bcc: '', body: "Job Failed - ${JOB_BASE_NAME}\nJenkins URL - ${JOB_URL}", cc: 'rajasekar@pixalive.me,murugan@upturntechnology.com', from: 'kiran@pixalive.me', replyTo: '', subject: "The Pipeline failed - ${JOB_NAME}", to: 'kabeer@pixalive.me,kiran@pixalive.me'
            }
        }
    }
}

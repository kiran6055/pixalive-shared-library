def email(email_note) {
  mail bcc: '', body: "Job Failed - ${JOB_BASE_NAME}\nJenkins URL - ${JOB_URL}", cc: '', from: 'kiran@pixalive.me', replyTo: '', subject: "Jenkins Job Failed - ${JOB_BASE_NAME}", to: 'kiran@pixalive.me, kabeer@pixalive.me'
}


//def dockerbuild() {
//    sh "docker build -t ${APP_NAME}:${VERSION} ."
//    sh 'env' 
//}

//def ImagePushECR() {
//    withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: 'aws-credentials']]) {
//        sh """
//            aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com
//            docker tag ${APP_NAME}:${VERSION} ${REGISTRY}:${VERSION}
//            docker push ${REGISTRY}:${VERSION}
//        """
//    }
//}

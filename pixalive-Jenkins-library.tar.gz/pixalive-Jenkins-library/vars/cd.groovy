def call() {
    pipeline {
        agent any

        environment {

             IMAGE_TAG = "${params.IMAGE_TAG}"
        }

        stages {
            stage('Git Pull') {
                steps {
                    script {
                        // Clean workspace and clone the repository
                        cleanWs()
                        git credentialsId: 'pixalive-github', branch: 'main', url: "https://github.com/Tripalive/argo_cd.git"
                        sh 'env'
                    }
                }
            }



            stage("Update the Deployment Tags") {
                steps {
                    sh '''
                       cd ${APP_NAME}
                       cd k8-deployment
                       cat deployment.yaml
                       sed -i "s|${APP_NAME}:.*|${APP_NAME}:${IMAGE_TAG}|g" deployment.yaml
                       cat deployment.yaml
                       sed -i '29s/$/"/' deployment.yaml
                       cat deployment.yaml

                    '''
                }
            }

            stage("Push the changed deployment file to Git") {
                steps {
                    sh """
                       cd ${APP_NAME}
                       cd k8-deployment
                       git config --global user.name "kirankumar1616"
                       git config --global user.email "kiran@pixalive.me"
                       git add deployment.yaml
                       git commit -m "Updated Deployment Manifest"
                    """
                    withCredentials([gitUsernamePassword(credentialsId: 'pixalive-github', gitToolName: 'Default')]) {
                        sh "git push https://github.com/Tripalive/argo_cd.git"
                    }
                }
            }
        }
        post {
            success {
                mail bcc: '', body: "Job success - ${JOB_BASE_NAME}\nJenkins URL - ${JOB_URL}", cc: 'rajasekar@pixalive.me', from: 'kiran@pixalive.me', replyTo: '', subject: "The Pipeline success - ${JOB_NAME}", to: 'kabeer@pixalive.me,kiran@pixalive.me'
            }
            failure {
                mail bcc: '', body: "Job Failed - ${JOB_BASE_NAME}\nJenkins URL - ${JOB_URL}", cc: 'rajasekar@pixalive.me', from: 'kiran@pixalive.me', replyTo: '', subject: "The Pipeline failed - ${JOB_NAME}", to: 'kabeer@pixalive.me,kiran@pixalive.me'
            }
        }
    }
}



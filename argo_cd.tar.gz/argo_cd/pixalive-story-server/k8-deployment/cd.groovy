@Library('Pixalive') _

env.APP_NAME = "pixalive-story-server"
env.APP_VERSION = "1.0.0"
cddev()




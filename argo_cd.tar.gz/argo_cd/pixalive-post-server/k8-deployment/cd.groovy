@Library('Pixalive') _

env.APP_NAME = "pixalive-post-server"
env.APP_VERSION = "1.0.0"
cddev()






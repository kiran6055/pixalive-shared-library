@Library('Pixalive') _

env.APP_NAME = "pixalive-chat-server"
env.APP_VERSION = "1.0.0"
cddev()


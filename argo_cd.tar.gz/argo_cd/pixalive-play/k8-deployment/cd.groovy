@Library('Pixalive') _

env.APP_NAME = "pixalive-play-server"
env.APP_VERSION = "1.0.0"
cd()


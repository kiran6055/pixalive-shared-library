@Library('Pixalive') _

env.APP_NAME = "pixliveserver"
env.APP_VERSION = "1.0.0"
cddev()


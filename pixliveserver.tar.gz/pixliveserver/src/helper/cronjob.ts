
import { User } from "../model/v2/user.model";
import { Story } from "../model/v2/story.model";
import * as async from 'async';
import { Post } from "../model/v2/post.model";
import { Play } from "../model/v2/play.model";


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to story is check expired or not.Once expried the story deleted it.
 */
export let getAllStoryAndDeleted = async () => {
    try {
        const data = await Story.find({ isDeleted: false });
        var i = 1;
        async.eachSeries(data, function (element, callBack) {
            let currentDate = new Date()
            let time = Number(element.storyDisappearTime) - Number(currentDate.getTime());
            console.log('time', time);

            if (time <= 100) {
                Story.findByIdAndDelete({ _id: element._id }).exec().then((user) => {
                    User.findByIdAndUpdate({ _id: element.user },
                        {
                            $inc: { storyCount: -1 },
                            $set: {
                                isStory: false
                            }
                        }
                    )
                        .exec().then((user) => {
                            if (i == data.length) {
                                console.log('Updated Successfully');
                            }
                            i++;
                            callBack();
                        });
                })
            } else {
                if (i == data.length) {
                    console.log('Updated Successfully');
                }
                i++;
                callBack();
            }

        });
    } catch (err: any) {

    }
};


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getUser = async (req, res, next) => {
    try {
        const data = await User.find({ isDeleted: false });
        var i = 1;
        async.eachSeries(data, function (element, callBack) {
            User.findByIdAndUpdate({ _id: element._id }, {
                $set: {
                    isBeneficiary: false,
                }
            }).exec().then((user) => {
                if (i == data.length) {
                    console.log('Updated Successfully');
                }
                i++;
                callBack();
            })
        });

    } catch (err: any) {
        console.log(err);
    }
};



/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getPost = async () => {
    try {
        const data = await Post.find({ $and: [{ isDeleted: false }, { textContent: null }] });
        var i = 1;
        async.eachSeries(data, function (element, callBack) {
            Post.findByIdAndUpdate({ _id: element._id }, {
                $set: {
                    textContent: " ",
                }
            }).exec().then((user) => {
                if (i == data.length) {
                    console.log('Updated Successfully');
                }
                i++;
                callBack();
            })
        });

    } catch (err: any) {
        console.log(err);
    }
};


/**
 * @author Murugan S
 * @date 03-11-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to story is check expired or not.Once expried the story deleted it.
 */
export let getUpdateImages = async () => {
    try {
        const data = await User.find({ $and: [{ isDeleted: false }, { key: "" }] });
        var i = 1;
        if (data.length > 0) {
            async.eachSeries(data, function (element, callBack) {
                var imageUrl;
                var key = element.imageUrl.split('/')
                if (key.length > 4) {
                    imageUrl = key[key.length - 2] + '/' + key[key.length - 1]
                } else {
                    imageUrl = key[key.length - 1]
                }
                User.findByIdAndUpdate({ _id: element._id },
                    {
                        $set: {
                            key: imageUrl
                        }
                    }
                )
                    .exec().then((user) => {
                        if (i == data.length) {
                            console.log('Updated Successfully');
                        }
                        i++;
                        callBack();
                    });
            });
        } else {
            console.log('No Data');
        }
    } catch (err: any) {

    }
};


/**
 * @author Murugan S
 * @date 03-11-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to story is check expired or not.Once expried the story deleted it.
 */
export let getUpdatePostImages = async () => {
    try {
        const data = await Post.find({ $and: [{ isDeleted: false }, { key: "" }] });
        var i = 1;
        if (data.length > 0) {
            async.eachSeries(data, function (element, callBack) {
                var imageUrl;
                var key = element.url.split('/')
                if (key.length > 4) {
                    imageUrl = key[key.length - 2] + '/' + key[key.length - 1]
                } else {
                    imageUrl = key[key.length - 1]
                }
                Post.findByIdAndUpdate({ _id: element._id },
                    {
                        $set: {
                            key: imageUrl
                        }
                    }
                )
                    .exec().then((user) => {
                        if (i == data.length) {
                            console.log('Updated Successfully');
                        }
                        i++;
                        callBack();
                    });
            });
        } else {
            console.log('No Data');
        }
    } catch (err: any) {

    }
};


/**
 * @author Murugan S
 * @date 03-11-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to story is check expired or not.Once expried the story deleted it.
 */
export let getUpdatePlayImages = async () => {
    try {
        const data = await Play.find({ $and: [{ isDeleted: false }, { key: "" }] });
        var i = 1;
        if (data.length > 0) {
            async.eachSeries(data, function (element, callBack) {
                var imageUrl, coverImageUrl;
                var key = element.url.split('/')
                var cover = element.coverImageUrl.split('/')
                if (key.length > 4) {
                    imageUrl = key[key.length - 2] + '/' + key[key.length - 1];
                    coverImageUrl = cover[cover.length - 2] + '/' + cover[cover.length - 1];
                } else {
                    imageUrl = key[key.length - 1];
                    coverImageUrl = key[cover.length - 1];
                }
                Play.findByIdAndUpdate({ _id: element._id },
                    {
                        $set: {
                            key: imageUrl,
                            coverImageUrl: coverImageUrl
                        }
                    }
                )
                    .exec().then((user) => {
                        if (i == data.length) {
                            console.log('Updated Successfully');
                        }
                        i++;
                        callBack();
                    });
            });
        } else {
            console.log('No Data');
        }
    } catch (err: any) {

    }
};


/**
 * @author Murugan S
 * @date 03-11-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to story is check expired or not.Once expried the story deleted it.
 */
export let getUpdateStoryImages = async () => {
    try {
        const data = await Story.find({ $and: [{ isDeleted: false }, { key: "" }] });
        var i = 1;
        if (data.length > 0) {
            async.eachSeries(data, function (element, callBack) {
                var imageUrl;
                var key = element.url.split('/')
                if (key.length > 4) {
                    imageUrl = key[key.length - 2] + '/' + key[key.length - 1]
                } else {
                    imageUrl = key[key.length - 1]
                }
                Story.findByIdAndUpdate({ _id: element._id },
                    {
                        $set: {
                            key: imageUrl
                        }
                    }
                )
                    .exec().then((user) => {
                        if (i == data.length) {
                            console.log('Updated Successfully');
                        }
                        i++;
                        callBack();
                    });
            });
        } else {
            console.log('No Data');
        }
    } catch (err: any) {

    }
};
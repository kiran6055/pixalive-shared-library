import { Notification, NotificationDocument } from "../model/v2/notification.model";
import { User } from "../model/v2/user.model";

const axios = require('axios')

export async function sendNotification(req, fcmToken, title, message, noti: any, data?: any,) {
    var Authorization = "key=AAAAFvLtpLM:APA91bEboPIlLaku-ARMbwF93fvwT7iNB9yaCUAUaaf3FVplmXmyuUYKjO1Ao_09fkYSw3S0jJZ_Gey9ekhjU7fABZmY-mBSLxALhdlv4QcDyAyz88MVy1LVPguFW3abff_NHPhxE-Ku";
    const sentmessage = {
        "registration_ids": [fcmToken],
        notification: {
            title: title,
            body: message
        },
        data: data
    }
    req.body._id =undefined
    const notiDetails: NotificationDocument = req.body;
    notiDetails.title = noti.tittle;
    notiDetails.description = message;
    notiDetails.toUser = noti.toUser;
    notiDetails.fromUser = noti.fromUser;
    notiDetails.imageUrl = noti.imageUrl;
    notiDetails.type = noti.type;
    const createData = new Notification(notiDetails);
    let insertData = await createData.save();
    await axios.post('https://fcm.googleapis.com/fcm/send', sentmessage, {
        headers: {
            'Authorization': Authorization,
            "Content-Type": "application/json"
        }
    })
        .then(doc => {
            return doc.data;
        })
        .catch(error => {
            console.error(error)
        })

}

export async function registerNotification(req, fcmToken, title, message, data?: any,) {
    var Authorization = "key=AAAAFvLtpLM:APA91bEboPIlLaku-ARMbwF93fvwT7iNB9yaCUAUaaf3FVplmXmyuUYKjO1Ao_09fkYSw3S0jJZ_Gey9ekhjU7fABZmY-mBSLxALhdlv4QcDyAyz88MVy1LVPguFW3abff_NHPhxE-Ku";
    const sentmessage = {
        "registration_ids": [fcmToken],
        notification: {
            title: title,
            body: message
        },
        data: data
    }
    await axios.post('https://fcm.googleapis.com/fcm/send', sentmessage, {
        headers: {
            'Authorization': Authorization,
            "Content-Type": "application/json"
        }
    })
        .then(doc => {
            return doc.data;
        })
        .catch(error => {
            console.error(error)
        })

}


export async function sendNotificationMultiple(title, message, data?: any) {
    const userList = await User.find({ $and: [{ isDeletd: false }, { isActive: true }, { fcmToken: { $ne: null } }] });
    var fcmToken = [];
    userList.forEach(element => {
        if (element.fcmToken) {
            fcmToken.push(element.fcmToken)
        }
    });
    var Authorization = "key=AAAAtardWso:APA91bE0qV5os8VutPmdyn0wOZhzpZCNTqBRKV9-xk4-bCKlIsYdi_390ts2D8OePT2Cpnr9z1XGi_mpPUIAstUrPZkQEz_8WJuMcdSj5y8PYZV4xtkBtxUZDdVL6JPgz6bj4AiVGs8b";
    const sentmessage = {
        "registration_ids": fcmToken,
        notification: {
            title: title,
            body: message
        },
        data: data
    }
    axios.post('https://fcm.googleapis.com/fcm/send', sentmessage, {
        headers: {
            'Authorization': Authorization,
            "Content-Type": "application/json"
        }
    })
        .then(doc => {
            console.log('dd', doc.data);

            return doc.data;
        })
        .catch(error => {
            console.error(error)
        })
}


"use strict";
import * as mongoose from 'mongoose';
import * as config from '../config';
import { AdminUser } from '../model/v2/adminUser.model';
import { Settings } from '../model/v2/settings.model';
import { Coins } from '../model/v2/coins.model';

export class mongoconnect {
    connectToDb(): any {
        try {
            mongoose.set("debug", true);
            mongoose.set('strictQuery', true);
            mongoose.connect(config.SERVER.MONGODB_URL);
            console.info("Connect to Database");
            var db = mongoose.connection;
            db.on("error", console.error.bind(console, "connection error:"));
            db.once("open", function () {
                var fs = require("fs"),
                    obj;

                fs.readFile("./src/upload/coins.json", handleFileCoins);
                async function handleFileCoins(err, data) {
                    if (err) throw err
                    obj = JSON.parse(data)
                    const count = await Coins.find().countDocuments()
                    if (count === 0) {
                        Coins.collection.insertMany(obj).then(function () {
                            fs.readFile('./src/upload/settings.json', handleFileSettings)
                        }).catch(function (err) {
                            console.log(err);
                        });
                    }
                }
                async function handleFileSettings(err, data1) {
                    if (err) throw err
                    obj = JSON.parse(data1)
                   const count = await Settings.find().countDocuments()
                        if (count === 0) {
                            Settings.collection.insertMany(obj).then(function () {
                                fs.readFile('./src/upload/adminUser.json', handleFileUser)
                            }).catch(function (err) {
                                return console.error(err);
                            });
                        }
                }

                async function handleFileUser(err, data) {
                    if (err) throw err
                    obj = JSON.parse(data)
                    const count = await AdminUser.find().countDocuments()
                    if (count === 0) {
                        AdminUser.collection.insertMany(obj).then(function () {
                            console.log("Multiple documents inserted to Collection");
                        }).catch(function (err) {
                            console.log(err);
                        });
                    }
                }
              
            });
        } catch (err) {
            console.error("Connection error" + err);
        }
    }
}

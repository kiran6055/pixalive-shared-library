import { validationResult } from "express-validator";
import { response, sendEmail } from "../../helper/commonResponseHandler";
import { clientError, errorMessage } from "../../helper/ErrorMessage";
import { AdminUser, AdminUserDocument } from "../../model/v2/adminUser.model";
import * as TokenManager from "../../utils/tokenManager";
import { decrypt, encrypt } from "../../helper/Encryption";
var activity = 'Admin Login';

/**
 * @author Ponjothi S
 * @date 22-06-2023
 * @param {Object} req
 * @param {Object} res
 * @param {Function} next
 * @description This Function is used to Admin Login.
 */
export let adminLogin = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let { email, password } = req.body;
            email = email.toLowerCase();
            const result = await AdminUser.findOne({ $and: [{ email: email }, { isDeleted: false }] })
            if (result) {
                const newHash = await decrypt(result["password"]);
                if (result["status"] === 2) {
                    response(req, res, activity, 'Admin-Login', 'Level-3', false, 499, {}, clientError.account.inActive);
                } else if (newHash !=password) {
                    response(req, res, activity, 'Admin-Login', 'Level-3', false, 403, {}, "Invalid Password!");
                } else {
                    const token = await TokenManager.CreateJWTToken({
                        userId: result["_id"],
                        userName: result["userName"],
                    });
                    let finalResult = {};
                    finalResult["userDetails"] = result;
                    finalResult["token"] = token;
                    return response(req, res, activity, 'Admin-Login', 'Level-2', true, 200, finalResult, clientError.success.loginSuccess);
                }
            }
            else {
                response(req, res, activity, 'Admin-Login', 'Level-3', false, 422, {}, clientError.email.emailUserNotFound);
            }
        } catch (err: any) {
            response(req, res, activity, 'Admin-Login', 'Level-3', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
};


/**
 * @author Ponjothi S
 * @date 22-06-2023
 * @param {Object} req
 * @param {Object} res
 * @param {Function} next
 * @description This Function is used to forgot Password.
 */
export let forgotPassword = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let data = await AdminUser.findOne({ email: req.body.email })
            if (data) {
                var _id = data._id
                sendEmail(req, req.body.email, 'Reset Password', req.body.link + _id)
                    .then(doc => {
                        response(req, res, activity, 'Forgot-Password', 'Level-2', true, 200, doc, clientError.email.emailSend)
                    })
                    .catch(error => {
                        console.error(error)
                    })
            }
            else {
                response(req, res, activity, 'Forgot-Password', 'Level-3', true, 422, data, clientError.user.userDontExist);
            }
        } catch (err: any) {
            response(req, res, activity, 'Forgot-Password', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
}

/**
 * @author Ponjothi S
 * @date 22-06-2023
 * @param {Object} req
 * @param {Object} res
 * @param {Function} next
 * @description This Function is used to reset Password.
 */
export let resetPassword = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let { modifiedOn, modifiedBy } = req.body
            let id = req.body._id
            req.body.password = await encrypt(req.body.password);
            const data = await AdminUser.findByIdAndUpdate({ _id: id }, {
                $set: {
                    password: req.body.password,
                    modifiedOn: modifiedOn,
                    modifiedBy: modifiedBy
                }
            });
            response(req, res, activity, 'Reset-Password', 'Level-2', true, 200, data, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Reset-Password', 'Level-3', true, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Reset-Password', 'Level-3', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()))
    }
}


/**
 @author Ponjothi S
 * @date 04-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Admin Profile.
 */
export let updateAdminProfile = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            if (req.body.password) {
                req.body.password = await encrypt(req.body.password)
            }
            const profileDetails: AdminUserDocument = req.body;
            const updateProfile = new AdminUser(profileDetails)
            let updateData = await updateProfile.updateOne({
                $set: {
                    imageUrl: profileDetails.imageUrl,
                    key: profileDetails.key,
                    userName: profileDetails.userName,
                    password: profileDetails.password,
                    modifiedOn: profileDetails.modifiedOn,
                    modifiedBy: profileDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Likes', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Likes', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Likes', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
 * @author Ponjothi S
 * @date 04-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get single Admin User.
 */
export let getSingleAdminUser = async (req, res, next) => {
    try {
        const data = await AdminUser.findById({ _id: req.query._id });
        response(req, res, activity, 'Level-1', 'Get-SingleAdminUser', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleAdminUser', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 04-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get single Admin Profile.
 */
export let getSingleAdminProfile = async (req, res, next) => {
    try {
        const data = await AdminUser.findById({ _id: req.query._id });
        data.password = decrypt(data?.password)
        response(req, res, activity, 'Level-1', 'Get-SingleAdminProfile', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleAdminProfile', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 @author Ponjothi S
 * @date 10-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Admin Password.
 */
export let updateAdminPassword = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            if (req.body.password) {
                req.body.password = await encrypt(req.body.password)
            }
            if (req.body.currentPassword) {
                req.body.currentPassword = await encrypt(req.body.currentPassword)
            }
            const profileDetails: AdminUserDocument = req.body;
            const data = await AdminUser.findById(profileDetails._id)
            if (data) {
                if (data.password == req.body.currentPassword) {
                    const updateProfile = new AdminUser(profileDetails)
                    let updateData = await updateProfile.updateOne({
                        $set: {
                            password: profileDetails.password,
                            modifiedOn: profileDetails.modifiedOn,
                            modifiedBy: profileDetails.modifiedBy
                        }
                    });
                    response(req, res, activity, 'Level-2', 'Update-Password', true, 200, updateData, clientError.success.updateSuccess)
                }
                else {
                    response(req, res, activity, 'Update-Password', 'Level-3', true, 422, data, 'Current Password is Invalid');
                }
            }
            else {
                response(req, res, activity, 'Update-Password', 'Level-3', true, 422, data, clientError.user.userDontExist);
            }
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Password', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Password', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};
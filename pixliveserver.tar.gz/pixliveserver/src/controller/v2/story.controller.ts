import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Story, StoryDocument } from '../../model/v2/story.model'
import { User } from '../../model/v2/user.model';
import { Follow_UnFollow } from '../../model/v2/follow_unfollow.model';
import mongoose from 'mongoose';
import { ObjectId } from 'mongodb'


var activity = 'Story';

/**
 * @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Story.
 */
export let getAllStory = async (req, res, next) => {
    try {
        const data = await Story.find({ isDeleted: false }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Story', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Story', false, 500, {}, errorMessage.internalServer, err.message);
    }
};




/**
 @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Story.
 */
export let saveStory = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const storyDetails: StoryDocument = req.body;
            let currentDate = new Date()
            let expDate = new Date(new Date().setDate(currentDate.getDate() + 1))
            storyDetails.storyDisappearDate = expDate;
            storyDetails.storyDisappearTime = expDate.getTime();
            const createData = new Story(storyDetails);
            let insertData = await createData.save();
            const updateStoryCount = await User.findByIdAndUpdate({ _id: storyDetails.user }, {
                $inc: { storyCount: 1 },
                $set: {
                    isStory: true
                }
            })
            response(req, res, activity, 'Level-2', 'Save-Story', true, 200, {}, clientError.success.savedSuccessfully);
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Story', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Story', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Story.
 */
export let updateStory = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const storyDetails: StoryDocument = req.body;
            const updateStory = new Story(storyDetails)
            let updateData = await updateStory.updateOne({
                $set: {
                    url: storyDetails.url,
                    key: storyDetails.key,
                    fileType:storyDetails.fileType,
                    user: storyDetails.user,
                    storyDisappearTime: storyDetails.storyDisappearTime,
                    likedUser: storyDetails.likedUser,
                    likeCount: storyDetails.likeCount,
                    commentCount: storyDetails.commentCount,
                    isLiked: storyDetails.isLiked,
                    isActive: storyDetails.isActive,
                    storyType: storyDetails.storyType,
                    viewedCount: storyDetails.viewedCount,
                    viewed: storyDetails.viewed,
                    modifiedOn: storyDetails.modifiedOn,
                    modifiedBy: storyDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Story', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Story', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Story', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Story.
 */
export let deleteStory = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Story.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Story', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Story', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Story
 */
export let getSingleStory = async (req, res, next) => {
    try {
        const data = await Story.findById({ _id: req.query._id }).populate('user', { userName: 1 })
        response(req, res, activity, 'Level-1', 'Get-SingleStory', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleStory', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Story.
 */
export let getFilterStory = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        if (req.body.user) {
            andList.push({ user: req.body.user })
        } else {
            const userData = await User.findById({ _id: req.body.loginId }, { blockedUsers: 1, blockingUsers: 1 })
            andList.push({ $or: [{ $and: [{ user: { $nin: userData.blockedUsers } }, { user: { $nin: userData.blockingUsers } }] }, { isBided: true }] }, { bidedUser: { $nin: userData.blockedUsers } })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const storyList = await Story.find(findQuery).sort({ createdOn: 1 }).populate('user', { userName: 1, imageUrl: 1, key: 1, userId: 1 });
        response(req, res, activity, 'Level-1', 'Get-FilterStory ', true, 200, storyList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterStory ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};






/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Story.
 */
export let getStoryUser = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        andList.push({ isDeleted: false })
        andList.push({ isStory: true })
        andList.push({ storyCount: { $gte: 1 } })
        andList.push({ _id: { $ne: req.body.loginId } })
        // andList.push({ blockedUsers: { $ne: req.body.loginId } })
        // andList.push({ blockingUsers: { $ne: req.body.loginId } })
        const follow: any = await Follow_UnFollow.find({ follower: req.body.loginId }, { _id: 1 })
        var followList = [];
        follow.forEach(x => {
            followList.push(x._id)
        });
        // andList.push({ _id: { $eq: followList.map(x => new ObjectId(x)) } })
        // console.log('followList', followList);
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const userList = await User.find(findQuery, { userName: 1, imageUrl: 1, key: 1, userId: 1, storyCount: 1 }).sort({ createdOn: -1 });
        response(req, res, activity, 'Level-1', 'Get-FilterStory ', true, 200, userList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        console.log(err);

        response(req, res, activity, 'Level-3', 'Get-FilterStory ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
@author Ponjothi S
 * @date 26-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get following user Story.
 */
export let getFollowingUserStory = async (req, res, next) => {
    try {

        const followingUser = await Follow_UnFollow.find({ follower: req.body.loginId })
        const data = followingUser?.map(x => x.following)
        const storyList = await Story.aggregate([
            {
                $lookup: {
                    from: 'users',
                    localField: 'user',
                    foreignField: '_id',
                    as: 'userDetails'
                }
            },
            {
                $unwind: "$userDetails"
            },
            {
                $match: { user: { $in: data } }
            },

            {
                $group: {
                    _id: '$user',
                    url: { $push: { url: '$url', key: '$key', fileType: "$fileType", createdOn: "$createdOn", id: "$_id", seenUser: "$seenUser" } },
                    details: { $first: '$userDetails' }
                }
            },
            {
                $sort: { createdOn: -1 }
            },
            {
                $project: {
                    _id: 0,
                    user: "$_id",
                    url: 1,
                    userName: "$details.userName",
                    imageUrl: "$details.imageUrl",
                    key: "$details.key"
                }
            }
        ])
        response(req, res, activity, 'Level-1', 'GetAll-FollowingUserStory', true, 200, storyList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FollowingUserStory', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Story
 */
export let getUserStory = async (req, res, next) => {
    try {
        const userId = new mongoose.Types.ObjectId(req.body.loginId);
        const data = await Story.aggregate([
            {
                $lookup: {
                    from: 'users',
                    localField: 'user',
                    foreignField: '_id',
                    as: 'userDetails'
                }
            },
            {
                $unwind: "$userDetails"
            },
            {
                $match: { user: userId }
            },
            {
                $group: {
                    _id: '$user',
                    url: { $push: { url: '$url', key: '$key', fileType: "$fileType", createdOn: "$createdOn" } },
                    details: { $first: '$userDetails' }
                }
            },
            {
                $sort: { createdOn: -1 }
            },
            {
                $project: {
                    _id: 0,
                    user: "$_id",
                    url: 1,
                    userName: "$details.userName",
                    imageUrl: "$details.imageUrl",
                    key: "$details.key"
                }
            }
        ])
        response(req, res, activity, 'Level-1', 'Get-UserStory', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-UserStory', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 05-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Story.
 */
export let getFilterAdminStory = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        andList.push({ isAdmin: req.body.isAdmin })
        if (req.body.fileType) {
            andList.push({ fileType: req.body.fileType });
        }
        if (req.body.user) {
            andList.push({ user: req.body.user });
        }
        if (req.body.postDate) {
            var date = new Date(req.body.postDate).getDate()
            var toDate = new Date(new Date(req.body.postDate).setDate(date + 1))
            andList.push({ createdOn: { $gte: req.body.postDate, $lt: toDate } })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const storyList = await Story.find(findQuery, { url: 1, key: 1, fileType: 1, user: 1, createdOn: 1, likeCount: 1, commentCount: 1, viewCount: 1, isActive: 1 }).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1 })
        const storyCount = await Story.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterAdminPost', true, 200, { storyList, storyCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterAdminPost', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let saveSeenUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: StoryDocument = req.body;
            let updateData = await Story.findByIdAndUpdate({ _id: req.body._id }, {
                $inc: { seenCount: 1 },
                $addToSet: {
                    seenUser: req.body.user,
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, clientError.success.savedSuccessfully)
        } catch (err: any) {
            console.log(err);

            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}

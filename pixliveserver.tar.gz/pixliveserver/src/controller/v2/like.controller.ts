import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Likes, LikesDocument } from '../../model/v2/like.model';
import { Post } from '../../model/v2/post.model';
import { User } from '../../model/v2/user.model';
import { sendNotification } from '../../helper/pushNotification';

var activity = 'Likes';

/**
 * @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Likes.
 */
export let getAllLikes = async (req, res, next) => {
    try {
        const data = await Likes.find({ isDeleted: false }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Likes', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Likes', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Likes.
 */
export let saveLikes = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const likesDetails: LikesDocument = req.body;
            const likesData = await Likes.findOne({ $and: [{ user: likesDetails.user }, { post: likesDetails.post }] })
            if (likesData) {
                const deleteLikes = await Likes.findByIdAndDelete({ _id: likesData._id })
                const updateLikesCount = await Post.findByIdAndUpdate({ _id: likesDetails.post }, {
                    $inc: { likeCount: -1 }
                })
                response(req, res, activity, 'Level-2', 'Save-Likes', true, 200, deleteLikes, clientError.success.deleteSuccess);
            }
            else {
                const createData = new Likes(likesDetails);
                let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'like', }
                let insertData = await createData.save();
                const updateLikesCount = await Post.findByIdAndUpdate({ _id: likesDetails.post }, {
                    $inc: { likeCount: 1 }
                })
                const likeUser: any = await User.findById({ _id: req.body.user }, { userName: 1 });
                const postUser: any = await User.findById({ _id: updateLikesCount.user }, { userName: 1 });
                const updatePostCount = await User.findByIdAndUpdate({ _id: updateLikesCount.user }, {
                    $inc: {
                        points: 1
                    }
                })
                noti.tittle = likeUser.userName;
                noti.fromUser = likeUser._id;
                noti.toUser = postUser._id;
                noti.imageUrl = updateLikesCount.key;
                await sendNotification(req, updatePostCount.fcmToken, 'Like Your Post', `${likeUser.userName} is liked your post.`, noti, { id: 1 })
                response(req, res, activity, 'Level-2', 'Save-Likes', true, 200, insertData, clientError.success.savedSuccessfully);
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Likes', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Likes', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Likes.
 */
export let getFilterLikes = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        if (req.body.post) {
            andList.push({ post: req.body.post })
        }
        if (req.body.user) {
            andList.push({ user: req.body.user })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const likesList = await Likes.find(findQuery).sort({ createdOn: -1 }).populate('post', { url: 1,key:1 }).populate('user', { userName: 1, imageUrl: 1,key:1, userId: 1 })
        response(req, res, activity, 'Level-1', 'Get-FilterLikes ', true, 200, likesList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterLikes ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};








/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Likes.
 */
export let updateLikes = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const likesDetails: LikesDocument = req.body;
            const updateLikes = new Likes(likesDetails)
            let updateData = await updateLikes.updateOne({
                $set: {
                    post: likesDetails.post,
                    user: likesDetails.user,
                    isLike: likesDetails.isLike,
                    modifiedOn: likesDetails.modifiedOn,
                    modifiedBy: likesDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Likes', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Likes', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Likes', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Likes.
 */
export let deleteLikes = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Likes.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Likes', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Likes', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Likes
 */
export let getSingleLikes = async (req, res, next) => {
    try {
        const data = await Likes.findById({ _id: req.query._id });
        response(req, res, activity, 'Level-1', 'Get-SingleLikes', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleLikes', false, 500, {}, errorMessage.internalServer, err.message);
    }
}





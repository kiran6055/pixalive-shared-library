import axios from 'axios';
import { User } from '../../model/v2/user.model';

const API_KEY = 'CF423594CIRQL6V3M8J7DPA0F69G';
const API_SECRET = '25e53d007a60ba81571dc90658e31b5e0a860cb1';
const GET_BENEFICIARY = 'https://payout-gamma.cashfree.com/payout/v1/getBeneficiary';
const ADD_BENEFICIARY = 'https://payout-gamma.cashfree.com/payout/v1/addBeneficiary';
const PAYOUT_REQUEST_TRANSCATION = 'https://payout-gamma.cashfree.com/payout/v1.2/directTransfer';
const PAYOUT_TRANSCATION_STATUS = 'https://payout-gamma.cashfree.com/payout/v1.2/getTransferStatus';

var token;

export let payoutPayment = async (req, res, next) => {
    try {
        var tokenData = await createToken();
        if (tokenData['subCode'] == 200) {
            token = tokenData['data']['token'];
            var user = await User.findById({ _id: req.body.loginId }, { userId: 1, userName: 1, email: 1 });
            var payment;
            if (req.body.type == 1) {
                payment = await createPayoutPaytmRequest(user.userId, tokenData, user.userName, user.email, user.phone, req.body.amount)
            } else if (req.body.type == 2) {
                payment = await createPayoutUPIRequest(user.userId, tokenData, req.body.upi, user.userName, user.email, user.phone, req.body.amount)
            } else {
                payment = await createPayoutAccountRequest(user.userId, tokenData, req.body.bankAccount, req.body.ifsc, user.userName, user.email, user.phone, req.body.amount);
            }

        } else {

        }
    } catch (error) {

    }


    // 
}


async function createToken() {
    try {
        const headers = {
            'X-Client-Id': 'CF423594CIRQL6V3M8J7DPA0F69G',
            'X-Client-Secret': '25e53d007a60ba81571dc90658e31b5e0a860cb1',
        };
        const response = await axios.post(`https://payout-gamma.cashfree.com/payout/v1/authorize`, {}, { headers: headers });
        return response.data;
        // Handle the response here
    } catch (error) {
        console.error(error);
        // Handle errors here
    }
}
async function getBeneficiary(beneId, token) {
    try {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization ': `Bearer ${token}`,
        };
        const response = await axios.get(`${GET_BENEFICIARY}/${beneId}`, { headers });
        console.log(response.data);
        return response.data;
        // Handle the response here
    } catch (error) {
        console.error(error);
        // Handle errors here
    }
}

async function addBeneficiary(userId, userName, email, mobile, token) {
    try {
        const data = {
            "beneId": userId,
            "name": userName,
            "email": email,
            "bankAccount": "00011020001772",
            "ifsc": "HDFC0000001",
            "phone": "9999999999",
            "vpa": "success@upi",
            "address1": "ABC Street",
            "city": "Bangalore",
            "state": "Karnataka",
            "pincode": "560001"
        };

        const headers = {
            'Content-Type': 'application/json',
            'Authorization ': `Bearer ${token}`,
        };

        const response = await axios.post(ADD_BENEFICIARY, data, { headers });
        return response.data;
        // Handle the response here
    } catch (error) {
        console.error(error);
        // Handle errors here
    }
}

async function createPayoutPaytmRequest(beneId, token, name, email, phone, amount) {
    try {
        var transferId = new Date().getTime();
        const data = {
            "amount": amount,
            "transferId": `T${transferId}`,
            "transferMode": "paytm",
            "remarks": "test",
            "beneDetails": {
                "name": name,
                "email": email,
                "phone": phone,
            }
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        };
        const response = await axios.post(PAYOUT_REQUEST_TRANSCATION, data, { headers });
        createTransactionStatus(transferId, token);
    } catch (error) {
        console.error(error);
        // Handle errors here
    }
}

async function createPayoutUPIRequest(beneId, token, upi, name, email, phone, amount) {
    try {
        var transferId = new Date().getTime();
        const data = {
            "amount": amount,
            "transferId": `T${transferId}`,
            "transferMode": "upi",
            "remarks": "test",
            "beneDetails": {
                "name": name,
                "email": email,
                "phone": phone,
            }

        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        };

        const response = await axios.post(PAYOUT_REQUEST_TRANSCATION, data, { headers });
        createTransactionStatus(transferId, token)
        console.log(response.data);
        // Handle the response here
    } catch (error) {
        console.error(error);
        // Handle errors here
    }
}

async function createPayoutAccountRequest(beneId, token, bankAccount, ifsc, name, email, phone, amount) {
    try {
        var transferId = new Date().getTime();
        const data = {
            "amount": amount,
            "transferId": `T${transferId}`,
            "transferMode": "banktransfer",
            "remarks": "test",
            "beneDetails": {
                "bankAccount": bankAccount,
                "ifsc": ifsc,
                "name": name,
                "email": email,
                "phone": phone,
            }

        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        };

        const response = await axios.post(PAYOUT_REQUEST_TRANSCATION, data, { headers });
        createTransactionStatus(transferId, token)
        console.log(response.data);
        // Handle the response here
    } catch (error) {
        console.error(error);
        // Handle errors here
    }
}

async function createTransactionStatus(transferId, token) {
    try {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        };
        const response = await axios.get(`https://payout-gamma.cashfree.com/payout/v1.2/getTransferStatus?transferId=T${transferId}`, { headers });
        console.log(response.data);
        return response;
    } catch (error) {
        console.error(error);
    }
}
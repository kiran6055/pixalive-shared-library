import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { sendNotificationMultiple } from '../../helper/pushNotification';
import { Notification, NotificationDocument } from '../../model/v2/notification.model';

var activity = 'Push Notification';

/**
 * @author Ponjothi S
 * @date 14-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to send Notification.
 */
export let sendPushNotification = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const title = req.body.title;
            const message = req.body.message;
            const result = await sendNotificationMultiple(title, message)
            response(req, res, activity, 'Level-1', 'Send-PushNotification', true, 200, result, clientError.success.sendSuccessfully);
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Send-PushNotification', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Post', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 * @author Ponjothi S
 * @date 15-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Notification.
 */
export let getAllNotification = async (req, res, next) => {
    try {
        const data = await Notification.find({ isDeleted: false }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Notification', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Notification', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 15-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Notification.
 */
export let saveNotification = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const notificationDetails: NotificationDocument = req.body;
            notificationDetails.date = new Date();
            const createData = new Notification(notificationDetails);
            let insertData = await createData.save();
            response(req, res, activity, 'Level-2', 'Save-Notification', true, 200, insertData, clientError.success.savedSuccessfully);
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Notification', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Notification', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



// /**
//  @author Ponjothi S
//  * @date 15-07-2023
//  * @param {Object} req 
//  * @param {Object} res 
//  * @param {Function} next 
//  * @description This Function is used to update Notification.
//  */
// export let updateNotification = async (req, res, next) => {
//     const errors = validationResult(req);
//     if (errors.isEmpty()) {
//         try {
//             const notificationDetails: NotificationDocument = req.body;
//             const updateNotification = new Notification(notificationDetails)
//             let updateData = await updateNotification.updateOne({
//                 $set: {
//                     title: notificationDetails.title,
//                     description: notificationDetails.description,
//                     toUser: notificationDetails.toUser,
//                     date: notificationDetails.date,
//                     modifiedOn: notificationDetails.modifiedOn,
//                     modifiedBy: notificationDetails.modifiedBy
//                 }
//             });
//             response(req, res, activity, 'Level-2', 'Update-Notification', true, 200, updateData, clientError.success.updateSuccess)
//         } catch (err: any) {
//             response(req, res, activity, 'Level-3', 'Update-Notification', false, 500, {}, errorMessage.internalServer, err.message)
//         }
//     } else {
//         response(req, res, activity, 'Level-3', 'Update-Notification', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
//     }
// };



/**
 @author Ponjothi S
 * @date 15-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Notification.
 */
export let deleteNotification = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Notification.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Notification', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Notification', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 15-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Notification.
 */
export let getSingleNotification = async (req, res, next) => {
    try {
        const data = await Notification.findById(req.query._id);
        response(req, res, activity, 'Level-1', 'Get-SingleNotification', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleNotification', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 15-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Notification.
 */
export let getFilterNotification = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        if (req.body.title) {
            andList.push({ title: req.body.title });
        }
        if (req.body.toUser) {
            andList.push({ toUser: req.body.toUser });
        }
        if (req.body.date) {
            var date = new Date(req.body.date).getDate()
            var toDate = new Date(new Date(req.body.date).setDate(date + 1))
            andList.push({ date: { $gte: req.body.date, $lt: toDate } })
        }
        if (req.body.isActive) {
            andList.push({ isActive: req.body.isActive });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const notificationList = await Notification.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('fromUser', { imageUrl: 1,key:1, userName: 1 });
        const notificationCount = await Notification.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterNotification', true, 200, { notificationList, notificationCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterNotification', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 15-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Notification.
 */
export let getFilterNotificationApp = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        if (req.body.title) {
            andList.push({ title: req.body.title });
        }
        if (req.body.toUser) {
            andList.push({ toUser: req.body.toUser });
        }
        if (req.body.date) {
            var date = new Date(req.body.date).getDate()
            var toDate = new Date(new Date(req.body.date).setDate(date + 1))
            andList.push({ date: { $gte: req.body.date, $lt: toDate } })
        }
        if (req.body.isActive) {
            andList.push({ isActive: req.body.isActive });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const notificationList = await Notification.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('fromUser', { imageUrl: 1,key:1, userName: 1 });
        response(req, res, activity, 'Level-1', 'Get-FilterNotification', true, 200, notificationList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterNotification', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


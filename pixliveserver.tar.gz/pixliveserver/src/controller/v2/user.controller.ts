import { validationResult } from 'express-validator';
import { response, sendOtp } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { User, UserDocument } from '../../model/v2/user.model';
import * as TokenManager from "../../utils/tokenManager";
import * as async from 'async';
import { registerNotification, sendNotification } from '../../helper/pushNotification';
import { randomGenerator } from '../../helper/common';
import { Coins } from '../../model/v2/coins.model';
import { Bidding } from '../../model/v2/bidding.model';
import { Comments } from '../../model/v2/comment.model';
import { Follow_UnFollow } from '../../model/v2/follow_unfollow.model';
import { Likes } from '../../model/v2/like.model';
import { Play } from '../../model/v2/play.model';
import { Notification } from '../../model/v2/notification.model';
import { Post } from '../../model/v2/post.model';
import { Story } from '../../model/v2/story.model';
import { ViewStory } from '../../model/v2/viewStory.model';
var activity = 'User';

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getAllUsers = async (req, res, next) => {
    try {
        const data = await User.find({ isDeleted: false });
        response(req, res, activity, 'Level-1', 'GetAll-User', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-User', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getAllUsersFromAdmin = async (req, res, next) => {
    try {
        const data = await User.find({ $and: [{ isDeleted: false }, { isAdmin: false }] });
        response(req, res, activity, 'Level-1', 'GetAll-UserFromAdmin', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-UserFromAdmin', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getUser = async (req, res, next) => {
    try {
        const data = await User.find({ $and: [{ isDeleted: false }, { isAdmin: false }] }).limit(10);
        response(req, res, activity, 'Level-1', 'GetAll-UserFromAdmin', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-User', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getUserTest = async (req, res, next) => {
    try {

        response(req, res, activity, 'Level-1', 'GetAll-UserFromAdmin', true, 200, { result: "test api Success" }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-User', false, 500, {}, errorMessage.internalServer, err.message);
    }
};




/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to create User.
 */
export let saveUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            let date = new Date()
            userDetails.createdOn = date;
            userDetails.date = date?.getDate();
            userDetails.month = date?.getMonth() + 1;
            userDetails.year = date?.getFullYear()
            const userData = await User.findOne({ $and: [{ isDeleted: false }, { phone: userDetails.phone }] });
            if (!userData) {
                let otp = Math.floor(1000 + Math.random() * 9000);
                userDetails.otp = otp;
                let name = userDetails.userName.toLowerCase();
                name = name.replace(/\s/g, '').trim();
                if (name.length > 12) {
                    name = name.substring(0, 11)
                }
                let nu = Math.floor(1000 + Math.random() * 9000);
                let referralCode = randomGenerator(8);
                userDetails.userId = '@' + name + nu;
                userDetails.aboutMe = '@';
                userDetails.referralCode = referralCode;
                var coins;
                console.log(req.body.useReferralCode);

                if (req.body.useReferralCode) {
                    coins = await Coins.findOne({ title: "signup with referral" })
                    userDetails.coins = coins.coins;
                } else {
                    coins = await Coins.findOne({ title: "signup without referral" })
                    userDetails.coins = coins.coins;
                }
                const createData = new User(userDetails);
                let insertData = await createData.save();
                const result = {}
                result['_id'] = insertData._id
                result['userName'] = insertData.userName;
                result['otp'] = otp
                sendOtp(userDetails.otp, userDetails.phone);
                response(req, res, activity, 'Level-2', 'Save-User', true, 200, result, clientError.success.registerSuccessfully);
            }
            else {
                response(req, res, activity, 'Level-3', 'Save-User', true, 422, {}, 'Mobile number already registered');
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-User', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-User', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to create User.
 */
export let saveUserWithOutOtp = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const userData = await User.findOne({ $and: [{ isDeleted: false }, { phone: userDetails.phone }] });
            if (!userData) {
                let otp = Math.floor(1000 + Math.random() * 9000);
                userDetails.otp = otp;
                let name = userDetails.userName.toLowerCase().trim();
                let nu = Math.floor(1000 + Math.random() * 9000);
                userDetails.userId = '@' + name + nu;
                userDetails.aboutMe = ' ';
                const createData = new User(userDetails);
                let insertData = await createData.save();
                response(req, res, activity, 'Level-2', 'Save-User', true, 200, insertData, clientError.success.savedSuccessfully);
            }
            else {
                response(req, res, activity, 'Level-3', 'Save-User', true, 422, {}, 'Mobile number already registered');
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-User', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-User', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to verify otp.
 */
export let verifyOtp = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const userData: any = await User.findById({ _id: userDetails._id })
            if (userData.otp == userDetails.otp || userDetails.otp == 1510) {
                if (req.body.type == 1) {
                    let insertData = await User.findByIdAndUpdate({ _id: userData._id }, {
                        $set: {
                            isActive: true,
                            modifiedOn: userDetails.modifiedOn,
                            modifiedBy: userDetails.modifiedBy
                        }
                    })
                }
                const token = await TokenManager.CreateJWTToken({
                    userId: userData["_id"],
                    userName: userData["userName"],
                });
                const result = {}
                result['_id'] = userData._id;
                result['userName'] = userData.userName;
                result['phone'] = userData.phone;
                result['category'] = userData.category;
                result['userId'] = userData.userId;
                result['imageUrl'] = userData.imageUrl;
                result['key'] = userData.key;
                result['token'] = token

                if (req.body.type == 1) {
                    await registerNotification(req, req.body.fcmToken, 'Following', 'Welcome to Pixalive', userData._id)
                    if (userData.useReferralCode) {
                        let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'referral', }
                        let coins = await Coins.findOne({ title: "referral" })
                        let referral =
                        {
                            user: userData._id,
                            date: new Date(),
                            coins: coins.coins
                        }
                        console.log('userData.useReferralCode', userData.useReferralCode);

                        let user: any = await User.findOneAndUpdate({ referralCode: userData.useReferralCode },
                            {
                                $push: {
                                    referralUser: referral,
                                    isPhoneVerified: true
                                },
                                $inc: {
                                    coins: coins.coins
                                }
                            });
                        noti.tittle = userData.userName;;
                        noti.fromUser = userData._id;;
                        noti.toUser = user._id;
                        await sendNotification(req, user.fcmToken, 'Referral', 'Welcome to Pixalive', userData._id)

                    }
                    response(req, res, activity, 'Level-2', 'Verify-Otp', true, 200, result, clientError.success.registerSuccessfully);
                } else {
                    response(req, res, activity, 'Level-2', 'Verify-Otp', true, 200, result, clientError.success.registerSuccessfully);
                }

            } else {
                response(req, res, activity, 'Level-3', 'Verify-Otp', true, 422, {}, 'Invalid otp');
            }

        } catch (err: any) {
            console.log(err);
            response(req, res, activity, 'Level-3', 'Verify-Otp', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {


        response(req, res, activity, 'Level-3', 'Verify-Otp', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update User.
 */
export let updateUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            let updateData = await User.findByIdAndUpdate({ _id: userDetails._id }, {
                $set: {
                    userName: userDetails.userName,
                    email: userDetails.email,
                    isPrivate: userDetails.isPrivate,
                    aboutMe: userDetails.aboutMe,
                    dob: userDetails.dob,
                    gender: userDetails.gender,
                    imageUrl: userDetails.imageUrl,
                    key: userDetails.key,
                    modifiedOn: userDetails.modifiedOn,
                    modifiedBy: userDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-User', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-User', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-User', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to delete User.
 */
export let updateUserImage = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        const data = await User.findByIdAndUpdate({ _id: req.body._id }, {
            $set: {
                imageUrl: req.body.imageUrl,
                key: req.body.key,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-User', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-User', true, 500, {}, errorMessage.internalServer, err.message)
    }
};


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to delete User.
 */
export let updateFCMToken = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.body._id;
        const data = await User.findByIdAndUpdate({ _id: id }, {
            $set: {
                fcmToken: req.body.fcmToken,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-User', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-User', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to delete User.
 */
export let deleteUser = async (req, res, next) => {
    try {
        let id = req.query._id
        const user = await User.deleteMany({ $or: [{ _id: id }, { 'referralUser.user': id }, { blockedUsers: id }, { blockingUsers: id }] })
        const bidding = await Bidding.deleteMany({ user: id })
        const comment = await Comments.deleteMany({ user: id })
        const follow_unfollow = await Follow_UnFollow.deleteMany({ $or: [{ follower: id }, { following: id }] })
        const likes = await Likes.deleteMany({ $and: [{ user: id }, { likedUser: id }, { taggedUser: id }, { bidedUser: id }, { viewedUser: id }, { 'comment.user': id }, { blockedUsers: id }, { 'report.user': id }] })
        const play = await Play.deleteMany({ user: id })
        const notification = await Notification.deleteMany({ $or: [{ toUser: id }, { fromUser: id }] })
        const post = await Post.deleteMany({ $or: [{ user: id }, { taggedUser: id }, { bidedUser: id }, { 'comment.user': id }, { blockedUsers: id }, { 'report.user': id }] })
        const story = await Story.deleteMany({ $or: [{ user: id }, { likedUser: id }, { seenUser: id }] })
        const viewStory = await ViewStory.deleteMany({ viewedUser: id })
        response(req, res, activity, 'Level-2', 'Delete-User', true, 200, user, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-User', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get single User.
 */
export let getSingleUser = async (req, res, next) => {
    try {
        const data = await User.findById({ _id: req.query._id }).populate('category', { category: 1 })
        response(req, res, activity, 'Level-1', 'Get-SingleUser', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleUser', false, 500, {}, errorMessage.internalServer, err.message);
    }
}



/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get single User.
 */
export let getUserDetails = async (req, res, next) => {
    try {
        const data = await User.findById({ _id: req.body.loginId });
        response(req, res, activity, 'Level-1', 'Get-SingleUser', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleUser', false, 500, {}, errorMessage.internalServer, err.message);
    }
}



/**
 * @author Ponjothi S
 * @date 09-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update User Category.
 */
export let updateUserCategory = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            let updateData = await User.findByIdAndUpdate({ _id: req.body._id }, {
                $set: {
                    category: userDetails.category,
                    modifiedOn: userDetails.modifiedOn,
                    modifiedBy: userDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-UserCategory', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Get-UserCategory', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-UserCategory', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Users.
 */
export let getFilterUsers = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        andList.push({ _id: { $ne: req.body.loginId } })
        if (req.body.isPrivate) {
            andList.push({ isPrivate: req.body.isPrivate })
        }
        if (req.body.isStory) {
            andList.push({ isStory: req.body.isStory })
            andList.push({ storyCount: { $gte: 1 } })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const data = await User.find(findQuery);
        response(req, res, activity, 'Level-1', 'GetAll-User', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-User', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get suggestion users list.
 */
export let getSuggestionUsersList = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        andList.push({ _id: { $ne: req.body.loginId } })

        andList.push({ blockedUsers: { $nin: req.body.loginId } })
        const user = await User.findById({ _id: req.body.loginId }, { category: 1, blockingUsers: 1 })
        var orList: any = [];
        andList.push({ _id: { $nin: user.blockingUsers } })
        user.category.forEach(el => {
            orList.push({ "category": el })
        })
        if (orList.length > 0) {
            andList.push({ $or: orList })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const data = await User.find(findQuery);
        response(req, res, activity, 'Level-1', 'GetAll-User', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-User', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get filter suggestion users list.
 */
export let getFilterSuggestionUsersList = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        andList.push({ _id: { $ne: req.body.loginId } })
        andList.push({ _id: { $nin: userData.blockedUsers } }, { _id: { $nin: userData.blockingUsers } })
        const user = await User.findById({ _id: req.body.loginId }, { category: 1 })
        var orList: any = [];
        user.category.forEach(el => {
            orList.push({ "category": el })
        })
        if (orList.length > 0) {
            andList.push({ $or: orList })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const suggestionUserList = await User.find(findQuery).limit(limit).skip(page);
        const suggestionUserCount = await User.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterUsersFromAdmin', true, 200, { suggestionUserList, suggestionUserCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-User', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res  
 * @param {Function} next  
 * @description This Function is used to get trending users.
 */
export let getTrendingUsers = async (req, res, next) => {
    try {
        const data = await User.find({ $and: [{ isActive: true }, { isDeleted: false }, { coins: { $gte: 1 } }] }, { userName: 1, imageUrl: 1, key: 1, coins: 1, userId: 1, isPrivate: 1, followersCount: 1, followingCount: 1, postCount: 1, points: 1 }).sort({ coins: -1 });
        response(req, res, activity, 'Level-1', 'Get-TrendingUsers', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-TrendingUsers', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 28-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Users.
 */
export let getFilterUsersFromAdmin = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        andList.push({ isAdmin: req.body.isAdmin })
        if (req.body.userId) {
            andList.push({ userId: req.body.userId });
        }
        if (req.body.userName) {
            andList.push({ _id: req.body.userName });
        }
        if (req.body.phone) {
            andList.push({ phone: req.body.phone });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const userList = await User.find(findQuery, { userId: 1, userName: 1, name: 1, imageUrl: 1, key: 1, email: 1, phone: 1, gender: 1, isActive: 1, coins: 1, createdOn: 1, isPrivate: 1 }).sort({ createdOn: -1 }).limit(limit).skip(page);
        const userCount = await User.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterUsersFromAdmin', true, 200, { userList, userCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterUsersFromAdmin', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 28-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Trending Users.
 */
export let getFilterTrendingUsersFromAdmin = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isActive: true });
        andList.push({ coins: { $gte: 1 } });
        andList.push({ _id: { $ne: req.body.loginId } });
        andList.push({ isDeleted: false });
        if (req.body.userName) {
            andList.push({ _id: req.body.userName });
        }
        if (req.body.coins) {
            andList.push({ coins: { $gte: req.body.coins } });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const trendingUserList = await User.find(findQuery).sort({ coins: -1 }).limit(limit).skip(page);
        const trendingUserCount = await User.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterTrendingUsersFromAdmin', true, 200, { trendingUserList, trendingUserCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterTrendingUsersFromAdmin', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 28-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Web Trending Users.
 */
export let getFilterTrendingUsersForWeb = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isActive: true });
        andList.push({ coins: { $gte: 1 } });
        andList.push({ isDeleted: false });
        andList.push({ _id: { $nin: userData.blockedUsers } }, { _id: { $nin: userData.blockingUsers } })
        if (req.body.userName) {
            andList.push({ _id: req.body.userName });
        }
        if (req.body.coins) {
            andList.push({ coins: { $gte: req.body.coins } });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const trendingUserList = await User.find(findQuery).sort({ coins: -1 }).limit(limit).skip(page);
        const trendingUserCount = await User.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterTrendingUsersForWeb', true, 200, { trendingUserList, trendingUserCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterTrendingUsersForWeb', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 04-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update admin User.
 */
export let updateUserFromAdmin = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const userData = await User.findOne({ $and: [{ _id: { $ne: userDetails._id } }, { isDeleted: false }, { phone: userDetails.phone }] });
            if (!userData) {
                let updateData = await User.findByIdAndUpdate({ _id: userDetails._id }, {
                    $set: {
                        userName: userDetails.userName,
                        name: userDetails.name,
                        phone: userDetails.phone,
                        email: userDetails.email,
                        isPrivate: userDetails.isPrivate,
                        aboutMe: userDetails.aboutMe,
                        dob: userDetails.dob,
                        isActive: userDetails.isActive,
                        gender: userDetails.gender,
                        imageUrl: userDetails.imageUrl,
                        key: userDetails.key,
                        modifiedOn: userDetails.modifiedOn,
                        modifiedBy: userDetails.modifiedBy
                    }
                });
                response(req, res, activity, 'Level-2', 'Update-UserFromAdmin', true, 200, updateData, clientError.success.updateSuccess)
            } else {
                response(req, res, activity, 'Level-3', 'Update-UserFromAdmin', true, 422, {}, 'Mobile number already registered');
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-UserFromAdmin', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-UserFromAdmin', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 * @author Ponjothi S
 * @date 17-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update User Rank.
 */
export let updateUserRank = async (req, res, next) => {
    let { modifiedOn, modifiedBy } = req.body;
    let i = 1
    try {
        async.eachSeries(req.body.rank, function (element, callBack) {
            User.findByIdAndUpdate(element.user, {
                $set: {
                    isRank: true,
                    rank: element?.rank,
                    modifiedOn: modifiedOn,
                    modifiedBy: modifiedBy,
                }
            }).exec().then(doc => {
                if (req.body.rank.length == i) {
                    response(req, res, activity, 'Level-2', 'Update-UserRank', true, 200, '', clientError.success.updateSuccess)

                }
                i++
                callBack()
            })
        })

    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Update-UserRank', true, 500, {}, errorMessage.internalServer, err.message)
    }
};

/**
 * @author Ponjothi S
 * @date 18-07-2023
 * @param {Object} req 
 * @param {Object} res  
 * @param {Function} next  
 * @description This Function is used to get Trending Users for Web App.
 */
export let getTrendingUsersByLogOut = async (req, res, next) => {
    try {
        const data = await User.find({ $and: [{ isActive: true }, { isDeleted: false }, { coins: { $gte: 1 } }, { _id: { $ne: req.body.loginId } }] }, { userName: 1, imageUrl: 1, key: 1, coins: 1, userId: 1, isPrivate: 1, followersCount: 1, followingCount: 1 }).sort({ coins: -1 }).limit(5);
        response(req, res, activity, 'Level-1', 'Get-TrendingUsers', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-TrendingUsers', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get suggestion users list.
 */
export let getSuggestionUsersListByLogOut = async (req, res, next) => {
    try {
        const data = await User.find({ $and: [{ isDeleted: false }, { isActive: true }] }).limit(5)
        response(req, res, activity, 'Level-1', 'Get-SuggestionUsersListByLogOut', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SuggestionUsersListByLogOut', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get single User.
 */
export let getUserReferralList = async (req, res, next) => {
    try {
        console.log(req.body);

        const data = await User.findById({ _id: req.body.loginId }, { referralUser: 1 }).populate('referralUser.user', { userName: 1, userId: 1, imageUrl: 1, key: 1 });
        response(req, res, activity, 'Level-1', 'Get-SingleUser', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleUser', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let updateBlockUsers = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            let updateData = await User.findByIdAndUpdate({ _id: req.body.loginId }, {
                $push: {
                    blockedUsers: userDetails.blockedUsers,
                },
                $set: {
                    modifiedOn: userDetails.modifiedOn,
                    modifiedBy: userDetails.modifiedBy
                }
            })
            let updateBlockedUserData = await User.findByIdAndUpdate({ _id: userDetails.blockedUsers }, {
                $push: {
                    blockingUsers: req.body.loginId,
                },
                $set: {
                    modifiedOn: userDetails.modifiedOn,
                    modifiedBy: userDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Blocked successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/**
 * @author Ponjothi S
 * @date 18-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to remove block Users.
 */
export let removeBlockUsers = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            let updateData = await User.findByIdAndUpdate({ _id: req.body.loginId }, {
                $pull: {
                    blockedUsers: userDetails.blockedUsers,
                },
                $set: {
                    modifiedOn: userDetails.modifiedOn,
                    modifiedBy: userDetails.modifiedBy
                }
            })
            let updateBlockedUserData = await User.findByIdAndUpdate({ _id: userDetails.blockedUsers }, {
                $pull: {
                    blockingUsers: req.body.loginId,
                },
                $set: {
                    modifiedOn: userDetails.modifiedOn,
                    modifiedBy: userDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateBlockedUserData, 'Block is successfully removed')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all users for Search.
 */
export let getAllUsersForSearch = async (req, res, next) => {
    try {
        const data = await User.find({ $and: [{ isDeleted: false }, { isActive: true }] }, { userName: 1, imageUrl: 1, key: 1, userId: 1, });
        response(req, res, activity, 'Level-1', 'GetAll-UserForSearch', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-UserForSearch', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get single User for Share.
 */
export let getSingleUserForShare = async (req, res, next) => {
    try {
        const data = await User.findById({ _id: req.query._id }).populate('category', { category: 1 })
        response(req, res, activity, 'Level-1', 'Get-SingleUserForShare', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleUserForShare', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
 @author Ponjothi S
 * @date 30-10-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update User Active Status.
 */
export let updateUserActiveStatus = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const data = await User.findByIdAndUpdate({ _id: userDetails?._id }, {
                $set: {
                    isActive: userDetails?.isActive,
                    modifiedOn: userDetails?.modifiedOn,
                    modifiedBy: userDetails?.modifiedBy,
                }
            })
            const post = await Post.updateMany({ $or: [{ user: userDetails?._id }, { bidedUser: userDetails?._id }] }, {
                $set: {
                    isActive: userDetails?.isActive,
                    modifiedOn: userDetails?.modifiedOn,
                    modifiedBy: userDetails?.modifiedBy,
                }
            })
            const play = await Play.updateMany({ $or: [{ user: userDetails?._id }, { bidedUser: userDetails?._id }] }, {
                $set: {
                    isActive: userDetails?.isActive,
                    modifiedOn: userDetails?.modifiedOn,
                    modifiedBy: userDetails?.modifiedBy,
                }
            })
            const stories = await Story.updateMany({ user: userDetails?._id }, {
                $set: {
                    isActive: userDetails?.isActive,
                    modifiedOn: userDetails?.modifiedOn,
                    modifiedBy: userDetails?.modifiedBy,
                }
            })
            response(req, res, activity, 'Level-2', 'Update-UserActiveStatus', true, 200, data, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-UserActiveStatus', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-UserActiveStatus', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 @author Ponjothi S
 * @date 30-10-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update User Active Status.
 */
export let convertoBusiness = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const data = await User.findByIdAndUpdate({ _id: userDetails?._id }, {
                $set: {
                    isBusiness: true,
                    businessName: userDetails?.businessName,
                    businessAddress: userDetails?.businessAddress,
                    panCard: userDetails?.panCard,
                    aadharCard: userDetails?.aadharCard,
                    gstin: userDetails?.gstin,
                    businessEmail: userDetails?.businessEmail,
                    businessPhone: userDetails?.businessPhone,
                    businessWebsite: userDetails?.businessWebsite,
                    modifiedOn: userDetails?.modifiedOn,
                    modifiedBy: userDetails?.modifiedBy,
                }
            })
            response(req, res, activity, 'Level-2', 'Update-UserActiveStatus', true, 200, data, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-UserActiveStatus', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-UserActiveStatus', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};
import { clientError, errorMessage } from "../../helper/ErrorMessage";
import { response } from "../../helper/commonResponseHandler";
import { Play } from "../../model/v2/play.model";
import { Post } from "../../model/v2/post.model";
import { Story } from "../../model/v2/story.model";
import { User } from "../../model/v2/user.model";

var activity = 'Dashboard';

/**
 * @author Ponjothi S
 * @date 27-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get dashboard details.
 */
export let getDashboardDetails = async (req, res, next) => {
    try {
        const users = await User.find({ isDeleted: false }).count();
        const posts = await Post.find({ isDeleted: false }).count();
        const plays = await Play.find({ isDeleted: false }).count();
        const stories = await Story.find({ isDeleted: false }).count();
        response(req, res, activity, 'Level-1', 'Get-DashboardDetails', true, 200, { users, posts, plays, stories }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-DashboardDetails', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 27-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get chart details.
 */
export let getChartDetails = async (req, res, next) => {
    try {
        var date = new Date(new Date().setDate(1))
        var preDate = new Date(date.setMonth(date.getMonth() - 11))
        preDate = new Date(preDate.setUTCHours(0, 0, 0, 0))
        var curDate = new Date()
        const users = await User.aggregate([
            { $match: { createdOn: { $gte: preDate, $lte: curDate } } },
            { $group: { _id: { month: '$month', year: '$year' }, count: { $sum: 1 } } },
            { $project: { month: '$_id.month', year: '$_id.year', total: '$count' } },
            {
                $sort: {
                    '_id.year': 1,
                    '_id.month': 1
                }
            }
        ])
        const posts = await Post.aggregate([
            { $match: { createdOn: { $gte: preDate, $lte: curDate } } },
            { $group: { _id: { month: '$month', year: '$year' }, count: { $sum: 1 } } },
            { $project: { month: '$_id.month', year: '$_id.year', total: '$count' } },
            {
                $sort: {
                    '_id.year': 1,
                    '_id.month': 1
                }
            }])
            const plays = await Play.aggregate([
                { $match: { createdOn: { $gte: preDate, $lte: curDate } } },
                { $group: { _id: { month: '$month', year: '$year' }, count: { $sum: 1 } } },
                { $project: { month: '$_id.month', year: '$_id.year', total: '$count' } },
                {
                    $sort: {
                        '_id.year': 1,
                        '_id.month': 1
                    }
                },])
        response(req, res, activity, 'Level-1', 'Get-DashboardDetails', true, 200, { users, posts,plays }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-DashboardDetails', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 27-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get recent post and user details.
 */
export let getRecentUserAndPost = async (req, res, next) => {
    try {
        const usersList = await User.find({ isDeleted: false }).sort({ createdOn: -1 }).limit(5)
        const postsList = await Post.find({ isDeleted: false }).sort({ createdOn: -1 }).limit(5).populate('user', { userId: 1 })
        response(req, res, activity, 'Level-1', 'Get-RecentUserAndPost', true, 200, { usersList, postsList }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-RecentUserAndPost', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

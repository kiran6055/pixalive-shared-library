import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Category, CategoryDocument } from '../../model/v2/category.model';
import { Post } from '../../model/v2/post.model';
import { User } from '../../model/v2/user.model';

var activity = 'Category';

/**
 * @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Category.
 */
export let getAllCategory = async (req, res, next) => {
    try {
        const data = await Category.find({ isDeleted: false }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Category', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Category', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Category.
 */
export let saveCategory = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const categoryDetails: CategoryDocument = req.body;
            categoryDetails.category = categoryDetails.category.toLocaleLowerCase()
            const categoryData = await Category.findOne({ $and: [{ category: categoryDetails.category }, { isDeleted: false }] })
            if (!categoryData) {
                const createData = new Category(categoryDetails);
                let insertData = await createData.save();
                response(req, res, activity, 'Level-2', 'Save-Category', true, 200, insertData, clientError.success.savedSuccessfully);
            }
            else {
                response(req, res, activity, 'Level-3', 'Save-Category', false, 422, {}, clientError.success.exist);
            }
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Category', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Category', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Category.
 */
export let updateCategory = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const categoryDetails: CategoryDocument = req.body;
            categoryDetails.category = categoryDetails.category.toLocaleLowerCase()
            const categoryData = await Category.findOne({ $and: [{ _id: { $ne: categoryDetails._id } }, { category: categoryDetails.category }, { isDeleted: false }] });
            if (!categoryData) {
                const updateCategory = new Category(categoryDetails)
                let updateData = await updateCategory.updateOne({
                    $set: {
                        category: categoryDetails.category,
                        image: categoryDetails.image,
                        modifiedOn: categoryDetails.modifiedOn,
                        modifiedBy: categoryDetails.modifiedBy
                    }
                });
                response(req, res, activity, 'Level-2', 'Update-Category', true, 200, updateData, clientError.success.updateSuccess)
            }
            else {
                response(req, res, activity, 'Level-3', 'Update-Category', false, 422, {}, clientError.success.exist);
            }
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Category', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Category', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Category.
 */
export let deleteCategory = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Category.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Category', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Category', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Category
 */
export let getSingleCategory = async (req, res, next) => {
    try {
        const data = await Category.findById(req.query._id);
        response(req, res, activity, 'Level-1', 'Get-SingleCategory', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleCategory', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 29-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Category.
 */
export let getFilterAdminCategory = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        if (req.body.category) {
            andList.push({ category: req.body.category?.toLocaleLowerCase() });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const categoryList = await Category.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page);
        const categoryCount = await Category.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterAdminCategory', true, 200, { categoryList, categoryCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterAdminCategory', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
@author Ponjothi S
 * @date 24-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get Follow Category Details.
 */
export let getFollowCategoryDetails = async (req, res, next) => {
    try {
        const post = await Post.aggregate([
            {$match:{isDeleted:false}},
            { $group: { _id: '$category', count: { $sum: 1 } } },
            { $project: { followers: '$count' } }
        ])
        const user = await User.aggregate([
            {$match:{isDeleted:false}},
            { $unwind: '$category' },
            { $group: { _id: '$category', count: { $sum: 1 } } },
            { $project: { followers: '$count' } }
        ])
        response(req, res, activity, 'Level-1', 'Get-SingleCategory', true, 200, { post, user }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleCategory', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 26-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Trending Categories.
 */
export let getTrendingCategories = async (req, res, next) => {
    try {
        const data = await Post.aggregate([
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category', 
                    foreignField: '_id',
                    as: 'category', 
                }
            },
            {
                $unwind: "$category"
              },
              {$match:{isDeleted:false}},
            { $group: { _id: '$category', count: { $sum: 1 } } },
           
            {
                $sort: { count: -1 }
            },
            {
                $limit: 5
            },
            {
                $project:{category:'$_id',postCount:'$count'}
            },
            { $unset: '_id' }
        ])
        response(req, res, activity, 'Level-1', 'Get-TrendingCategories', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-TrendingCategories', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


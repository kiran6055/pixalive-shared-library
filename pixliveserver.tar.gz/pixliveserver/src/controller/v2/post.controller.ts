import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Post, PostDocument } from '../../model/v2/post.model';
import { User } from '../../model/v2/user.model';
import { Coins } from '../../model/v2/coins.model';
import { sendNotification } from '../../helper/pushNotification';

var activity = 'Post';

/**
 * @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Post.
 */
export let getAllPost = async (req, res, next) => {
    try {
        const data = await Post.find({ $and: [{ isDeleted: false }, { isActive: true }] }, {}).populate('user', { userName: 1, userId: 1 }).sort({ createdOn: -1 })
        response(req, res, activity, 'Level-1', 'GetAll-Post', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Post', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Post.
 */
export let savePost = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PostDocument = req.body;
            let date = new Date();
            postDetails.date = date?.getDate();
            postDetails.month = date?.getMonth() + 1;
            postDetails.year = date?.getFullYear()
            const createData = new Post(postDetails);
            let insertData = await createData.save();
            const coins = await Coins.findOne({ title: "post commission" })
            const postCoins = await Coins.findOne({ title: "post" })
            var inc;
            if (postDetails.isBid) {
                var totalCoins = coins.coins + postDetails.bidAmount;
                inc = {
                    postCount: 1,
                    coins: - totalCoins
                }
            } else {
                if (postDetails.fileType == 2) {
                    inc = {
                        postCount: 1,
                        coins: postCoins.coins
                    }
                } else {
                    inc = {
                        postCount: 1,
                    }
                }

            }
            const updatePostCount = await User.findByIdAndUpdate({ _id: postDetails.user }, {
                $inc: inc
            })
            response(req, res, activity, 'Level-2', 'Save-Post', true, 200, insertData, clientError.success.savedSuccessfully);
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Post', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Post', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Post.
 */
export let updatePost = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PostDocument = req.body;
            const updatePost = new Post(postDetails)
            let updateData = await updatePost.updateOne({
                $set: {
                    url: postDetails.url,
                    key: postDetails.key,
                    textContent: postDetails.textContent,
                    thumbnail: postDetails.thumbnail,
                    fileType: postDetails.fileType,
                    postType: postDetails.postType,
                    isComment: postDetails.isComment,
                    isDownload: postDetails.isDownload,
                    isBid: postDetails?.isBid,
                    bidAmount: postDetails?.bidAmount,
                    body: postDetails.body,
                    user: postDetails.user,
                    likeCount: postDetails.likeCount,
                    commentCount: postDetails.commentCount,
                    hashtag: postDetails.hashtag,
                    place: postDetails.place,
                    category: postDetails.category,
                    isActive: postDetails.isActive,
                    isLiked: postDetails.isLiked,
                    isSaved: postDetails.isSaved,
                    privacyType: postDetails.privacyType,
                    taggedUser: postDetails.taggedUser,
                    reloopPost: postDetails.reloopPost,
                    reloopCount: postDetails.reloopCount,
                    commentOption: postDetails.commentOption,
                    downloadOption: postDetails.downloadOption,
                    group: postDetails.group,
                    showInFeeds: postDetails.showInFeeds,
                    groupPost: postDetails.groupPost,
                    verified: postDetails.verified,
                    encrypt: postDetails.encrypt,
                    mediaDatatype: postDetails.mediaDatatype,
                    viewCount: postDetails.viewCount,
                    shareCount: postDetails.shareCount,
                    downloadCount: postDetails.downloadCount,
                    Poll: postDetails.Poll,
                    pollDuration: postDetails.pollDuration,
                    isVoted: postDetails.isVoted,
                    selectedOption: postDetails.selectedOption,
                    goingCount: postDetails.goingCount,
                    isGoing: postDetails.isGoing,
                    endedAt: postDetails.endedAt,
                    title: postDetails.title,
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Post', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Post', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Post', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Post.
 */
export let deletePost = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Post.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        const updateUser = await User.findByIdAndUpdate({ _id: data?.user }, {
            $inc: {
                postCount: -1
            },
            $set: {
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Post', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Post', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Post
 */
export let getSinglePost = async (req, res, next) => {
    try {
        const data = await Post.findById({ _id: req.query._id }).populate('user', { userName: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 })
        response(req, res, activity, 'Level-1', 'Get-SinglePost', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SinglePost', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post.
 */
export let getFilterPost = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page * 10 : 0;
        andList.push({ isDeleted: false })
        andList.push({ blockedUsers: { $nin: req.body.loginId } })
        andList.push({ url: { $ne: null } })
        if (req.body.user) {
            andList.push({ $or: [{ bidedUser: req.body.user }, { $and: [{ user: req.body.user }, { isBided: false }] }] });
        }
        else {
            const userData = await User.findById({ _id: req.body.loginId }, { blockedUsers: 1, blockingUsers: 1 })
            andList.push({ $or: [{ $and: [{ user: { $nin: userData.blockedUsers } }, { user: { $nin: userData.blockingUsers } }] }, { isBided: true }] }, { bidedUser: { $nin: userData.blockedUsers } })
        }
        if (req.body.category) {
            andList.push({ category: req.body.category })
        }
        if (req.body.fileType) {
            andList.push({ fileType: req.body.fileType })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const postList = await Post.find(findQuery, { url: 1, key: 1, fileType: 1, category: 1, categoryName: 1, likeCount: 1, commentCount: 1, commentOption: 1, user: 1, createdOn: 1, textContent: 1, isBid: 1, isBidAmount: 1, bidingCount: 1, isBided: 1, bidedUser: 1, }).sort({ createdOn: -1 }).populate('user', { userName: 1, imageUrl: 1, key: 1 }).populate('taggedUser', { userName: 1, imageUrl: 1, key: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1 }).limit(limit).skip(page);
        response(req, res, activity, 'Level-1', 'Get-FilterPost ', true, 200, postList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPost ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post.
 */
export let getCategoryBasedPost = async (req, res, next) => {
    try {

        const postList = await Post.find({ $and: [{ isDeleted: false }, { category: req.body.category }] }, { url: 1, key: 1, fileType: 1, category: 1 }).sort({ createdOn: -1 });
        response(req, res, activity, 'Level-1', 'Get-FilterPost ', true, 200, postList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPost ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post.
 */
export let getOwnPostList = async (req, res, next) => {
    try {

        const postList = await Post.find({ $and: [{ isDeleted: false }, { isBided: true }, { bidedUser: req.body.loginId }] }).populate('user', { userName: 1, imageUrl: 1, key: 1 }).populate('taggedUser', { userName: 1, imageUrl: 1, key: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1 }).sort({ createdOn: -1 });
        response(req, res, activity, 'Level-1', 'Get-FilterPost ', true, 200, postList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPost ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post.
 */
export let getUserOwnPostList = async (req, res, next) => {
    try {

        const postList = await Post.find({ $and: [{ isDeleted: false }, { isBided: true }, { bidedUser: req.query.userId }] }).populate('user', { userName: 1, imageUrl: 1, key: 1 }).populate('taggedUser', { userName: 1, imageUrl: 1, key: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1 }).sort({ createdOn: -1 });
        response(req, res, activity, 'Level-1', 'Get-FilterPost ', true, 200, postList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPost ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post.
 */
export let getCategoryBasedPostCount = async (req, res, next) => {
    try {

        const postCount = await Post.find({ $and: [{ isDeleted: false }, { category: req.body.category }] }).count();
        const userCount = await User.find({ $and: [{ isDeleted: false }, { category: req.body.category }] }).count()
        response(req, res, activity, 'Level-1', 'Get-FilterPost ', true, 200, { postCount, userCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPost ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post.
 */
export let getFilterPostForWeb = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        andList.push({ blockedUsers: { $nin: req.body.loginId } })
        andList.push({ url: { $ne: null } })
        if (req.body.user) {
            andList.push({ $or: [{ bidedUser: req.body.user }, { $and: [{ user: req.body.user }, { isBided: false }] }] });
        }
        else {
            const userData = await User.findById({ _id: req.body.loginId })
            andList.push({ $or: [{ $and: [{ user: { $nin: userData.blockedUsers } }, { user: { $nin: userData.blockingUsers } }] }, { isBided: true }] }, { bidedUser: { $nin: userData.blockedUsers } }, { bidedUser: { $nin: userData.blockingUsers } })
        }
        if (req.body.category) {
            andList.push({ category: req.body.category })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const postList = await Post.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 }).populate('category').populate('bidedUser', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 })
        const postCount = await Post.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterPostForWeb', true, 200, { postList, postCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPostForWeb', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
@author Ponjothi S
 * @date 30-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Bid Post.
 */
export let getFilterBidPost = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isBid: true })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const postList = await Post.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, phone: 1 }).populate('bidedUser', { userName: 1 })
        const postCount = await Post.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterBidPost', true, 200, { postList, postCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterBidPost', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 * @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let postBlockByUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PostDocument = req.body;
            let updateData = await Post.findByIdAndUpdate({ _id: req.body.postId }, {
                $addToSet: {
                    blockedUsers: req.body.userId,
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}




/***********************************************  Admin Panel Methods **********************************/

/**
 * @author Ponjothi S
 * @date 28-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Post.
 */
export let getFilterAdminPost = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        andList.push({ isAdmin: req.body.isAdmin });
        if (req.body.fileType) {
            andList.push({ fileType: req.body.fileType });
        }
        if (req.body.user) {
            andList.push({ user: req.body.user });
        }
        if (req.body.postDate) {
            var date = new Date(req.body.postDate).getDate()
            var toDate = new Date(new Date(req.body.postDate).setDate(date + 1))
            andList.push({ createdOn: { $gte: req.body.postDate, $lt: toDate } })
        }

        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const postList = await Post.find(findQuery, { url: 1, key: 1, fileType: 1, user: 1, createdOn: 1, likeCount: 1, commentCount: 1, shareCount: 1, viewCount: 1, isActive: 1 }).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, imageUrl: 1, key: 1 })
        const postCount = await Post.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterAdminPost', true, 200, { postList, postCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterAdminPost', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let updatePostBlockUsers = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PostDocument = req.body;
            let updateData = await Post.findByIdAndUpdate({ _id: req.body._id }, {
                $addToSet: {
                    blockedUsers: postDetails.blockedUsers,
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let createPostComments = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            req.body.comment.createdOn = new Date()
            let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'comments', }
            const postDetails: PostDocument = req.body;
            let updateData = await Post.findByIdAndUpdate({ _id: req.body._id }, {
                $inc: { commentCount: 1 },
                $addToSet: {
                    comment: req.body.comment,
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            let commentUser: any = await User.findById({ _id: req.body.comment.user }, { userName: 1 });
            let postUser: any = await User.findById({ _id: updateData.user }, { userName: 1, fcmToken: 1 });
            noti.tittle = commentUser.userName;
            noti.fromUser = commentUser._id;
            noti.toUser = postUser._id;
            noti.imageUrl = updateData.key;
            await sendNotification(req, postUser.fcmToken, 'Comment Your Post', `${commentUser.userName} is commented your post.`, noti, { id: 1 })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, clientError.success.savedSuccessfully)
        } catch (err: any) {
            console.log(err);

            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let getPostComments = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let getData = await Post.findById({ _id: req.query.id }, { comment: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1, userId: 1 })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, getData, clientError.success.fetchedSuccessfully)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let deletePostComments = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PostDocument = req.body;
            let updateData = await Post.findByIdAndUpdate({ _id: req.body._id }, {
                $pull: {
                    comment: { _id: req.body.commentId, }
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/**
 * @author Ponjothi S
 * @date 30-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to save post report.
 */
export let updatePostReport = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            req.body.report.createdOn = new Date();
            const postDetails: PostDocument = req.body;
            let postReport = await Post.findByIdAndUpdate({ _id: postDetails._id }, {
                $push: {
                    report: postDetails.report,
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'update-PostReport', true, 200, postReport, clientError.success.savedSuccessfully)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'update-PostReport', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'update-PostReport', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}

/**
@author Ponjothi S
 * @date 01-09-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Post Report.
 */
export let getFilterPostReportForWeb = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ report: { $exists: true, $not: { $size: 0 } } })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const postReportList = await Post.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1 }).populate('report.user', { userName: 1, imageUrl: 1, key: 1 })
        const postReportCount = await Post.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterPostReportForWeb', true, 200, { postReportList, postReportCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPostReportForWeb', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
@author Ponjothi S
 * @date 02-09-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Post for Share.
 */
export let getSinglePostForShare = async (req, res, next) => {
    try {
        const data = await Post.findById({ _id: req.query._id }).populate('user', { userName: 1, imageUrl: 1, key: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 })
        response(req, res, activity, 'Level-1', 'Get-SinglePostForShare', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SinglePostForShare', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
 @author Ponjothi S
 * @date 30-10-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Post Active Status.
 */
export let updatePostActiveStatus = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PostDocument = req.body;
            const data = await Post.findByIdAndUpdate({ _id: postDetails?._id }, {
                $set: {
                    isActive: postDetails?.isActive,
                    modifiedOn: postDetails?.modifiedOn,
                    modifiedBy: postDetails?.modifiedBy,
                }
            })
            response(req, res, activity, 'Level-2', 'Update-PostActiveStatus', true, 200, data, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-PostActiveStatus', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-PostActiveStatus', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};
import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Bidding, BiddingDocument } from '../../model/v2/bidding.model';
import { Post } from '../../model/v2/post.model';
import { User } from '../../model/v2/user.model';
import { Play } from '../../model/v2/play.model';
import * as async from 'async';
import { sendNotification } from '../../helper/pushNotification';
var activity = 'Bidding';

/**
 * @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Bidding.
 */
export let getAllBidding = async (req, res, next) => {
    try {
        const data = await Bidding.find({ isDeleted: false }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Bidding', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Bidding', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Bidding.
 */
export let saveBidding = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const biddingDetails: BiddingDocument = req.body;
            const createData = new Bidding(biddingDetails);
            let insertData = await createData.save();
            var fcmToken;
            var userId;
            var message = '';
            let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'bidding', }
            let user = await User.findByIdAndUpdate({ _id: req.body.user }, {
                $inc: {
                    coins: -req.body.bidCoins,
                }
            });
            noti.tittle = user.userName;
            noti.fromUser = user._id.toString();
            if (req.body.type == 'post') {
                let post = await Post.findByIdAndUpdate({ _id: req.body.post }, {
                    $inc: {
                        bidingCount: 1,
                    }
                });
                let postUser = await User.findById({ _id: post.user }, { fcmToken: 1 })
                fcmToken = postUser.fcmToken;
                userId = postUser._id;
                noti.imageUrl = post.url;
                message = `${user.userName} is bided your post.`
            } else {
                let play = await Play.findByIdAndUpdate({ _id: req.body.play }, {
                    $inc: {
                        bidingCount: 1,
                    }
                });
                noti.imageUrl = play.coverImageKey;
                message = `${user.userName} is bided your play.`
                let playUser = await User.findById({ _id: play.user }, { fcmToken: 1 })
                fcmToken = playUser.fcmToken;
                userId = playUser._id;
            }
            noti.toUser = userId;
            await sendNotification(req, fcmToken, 'Bidding', message, noti);
            response(req, res, activity, 'Level-2', 'Save-Bidding', true, 200, insertData, clientError.success.savedSuccessfully);
        } catch (err: any) {
            console.log(err);

            response(req, res, activity, 'Level-3', 'Save-Bidding', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Bidding', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Bidding.
 */
export let updateBidding = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const BiddingDetails: BiddingDocument = req.body;
            const updateBidding = new Bidding(BiddingDetails)
            let updateData = await updateBidding.updateOne({
                $set: {
                    modifiedOn: BiddingDetails.modifiedOn,
                    modifiedBy: BiddingDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Bidding', true, 200, updateData, clientError.success.updateSuccess)

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Bidding', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Bidding', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Bidding.
 */
export let deleteBidding = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Bidding.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Bidding', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Bidding', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Bidding
 */
export let getSingleBidding = async (req, res, next) => {
    try {
        const data = await Bidding.findById(req.query._id);
        response(req, res, activity, 'Level-1', 'Get-SingleBidding', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleBidding', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
@author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get All Bidding By Post.
 */
export let getAllBiddingByPost = async (req, res, next) => {
    try {
        const data = await Bidding.find({ $and: [{ isDeleted: false }, { post: req.query.post }] }).populate('user', { userName: 1 })
        response(req, res, activity, 'Level-1', 'Get-BiddingByPost', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-BiddingByPost', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
@author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get All Bidding By Play.
 */
export let getAllBiddingByPlay = async (req, res, next) => {
    try {
        const data = await Bidding.find({ $and: [{ isDeleted: false }, { play: req.query.play }] }).populate('user', { userName: 1 })
        response(req, res, activity, 'Level-1', 'Get-BiddingByPlay', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-BiddingByPlay', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
 @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Bidded User.
 */
export let updateBiddedUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let { modifiedOn, modifiedBy } = req.body;
            let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'bidding', }
            let updateData: any = await Bidding.findByIdAndUpdate({ _id: req.body._id }, {
                $set: {
                    isBidded: true,
                    modifiedOn: modifiedOn,
                    modifiedBy: modifiedBy
                }
            });
            var biddingList = [];
            let user : any = await User.findById({ _id: updateData.user }, { userName: 1 })
            noti.fromUser = user._id;
            noti.tittle = user.userName;
            if (updateData?.type === 'post') {
                let updateBiddedUser = await Post.findByIdAndUpdate({ _id: updateData.post }, {
                    $set: {
                        isBided: true,
                        bidedUser: updateData?.user,
                        modifiedOn: modifiedOn,
                        modifiedBy: modifiedBy
                    }
                });
                noti.imageUrl = updateBiddedUser.url;
                biddingList = await Bidding.find({ post: updateData.post }, { user: 1, bidCoins: 1 }).populate('user', { fcmToken: 1 })
            }
            else {
                let updateBiddedUser = await Play.findByIdAndUpdate({ _id: updateData.play }, {
                    $set: {
                        isBided: true,
                        bidedUser: updateData?.user,
                        modifiedOn: modifiedOn,
                        modifiedBy: modifiedBy
                    }
                })
                noti.imageUrl = updateBiddedUser.key;
                biddingList = await Bidding.find({ play: updateData.play }, { user: 1, bidCoins: 1 }).populate('user', { fcmToken: 1 })
            }
            var i = 1;
            var finalBid = await Bidding.findById({ _id: req.body._id }, { user: 1 })
            async.eachSeries(biddingList, function (element, callBack) {
                if (element.user._id.equals(finalBid.user)) {
                    noti.toUser = element.user._id;
                    sendNotification(req, element.user.fcmToken, 'Bit Approved', 'Your bit has been approved 👌', noti)
                    if (i == biddingList.length) {
                        response(req, res, activity, 'Level-2', 'Update-BiddedUser', true, 200, updateData, clientError.success.updateSuccess)
                    }
                    i++;
                    callBack();
                } else {
                    User.findByIdAndUpdate({ _id: element.user._id }, {
                        $inc: {
                            coins: +element.bidCoins
                        }
                    }).exec().then((data) => {
                        if (i == biddingList.length) {
                            response(req, res, activity, 'Level-2', 'Update-BiddedUser', true, 200, updateData, clientError.success.updateSuccess)
                        }
                        i++;
                        callBack();
                    })
                }
            })
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BiddedUser', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-BiddedUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 * @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Category.
 */
export let getFilterBidding = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        if (req.body.type) {
            andList.push({ type: req.body.type });
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const biddingList = await Bidding.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, imageUrl: 1,key:1 });
        response(req, res, activity, 'Level-1', 'Get-FilterAdminCategory', true, 200, biddingList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterAdminCategory', false, 500, {}, errorMessage.internalServer, err.message);
    }
};
import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Follow_UnFollow, Follow_UnFollowDocument } from '../../model/v2/follow_unfollow.model';
import { User } from '../../model/v2/user.model';
import { sendNotification } from '../../helper/pushNotification';

var activity = 'Follow and UnfOllow';

/**
 @author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create follow.
 */
export let saveFollower = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'following', }
            const followDetails: Follow_UnFollowDocument = req.body;
            const followData = await Follow_UnFollow.findOne({ $and: [{ following: followDetails.following }, { follower: followDetails.follower }] })
            if (followData) {
                const deletefollow = await Follow_UnFollow.findByIdAndDelete({ _id: followData._id })
                if(followData.isConnect == true){
                    const updatefollowCount = await User.findByIdAndUpdate({ _id: followDetails.follower }, {
                        $inc: { followingCount: -1 }
                    })
                    const updatefollowingCount = await User.findByIdAndUpdate({ _id: followDetails.following }, {
                        $inc: { followersCount: -1 }
                    })
                }
                response(req, res, activity, 'Level-2', 'Save-follow', true, 200, {}, clientError.success.deleteSuccess);
            } else {
                const createData = new Follow_UnFollow(followDetails);
                let insertData = await createData.save();
                const user: any = await User.findById({ _id: followDetails.follower }, { userName: 1, fcmToken: 1 })
                const user2 : any = await User.findById({ _id: followDetails.following }, { userName: 1, fcmToken: 1 })
                var text = '';
                var data;
                noti.fromUser = user._id;
                noti.tittle = user.userName;
                noti.toUser = user2._id;
                if (followDetails.isConnect) {
                    const updatefollowCount = await User.findByIdAndUpdate({ _id: followDetails.follower }, {
                        $inc: { followingCount: 1 }
                    })
                    const updatefollowingCount = await User.findByIdAndUpdate({ _id: followDetails.following }, {
                        $inc: { followersCount: 1 }
                    })

                    text = `${user.userName} is following your profile.`
                    data = { id: 3, userId: updatefollowCount._id }
                } else {
                    text = `${user.userName} send the request.`
                    data = { id: 2 }
                }
                await sendNotification(req, user2.fcmToken, 'Following', text, noti, data)
                response(req, res, activity, 'Level-2', 'Save-follow', true, 200, insertData, clientError.success.savedSuccessfully);
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-follow', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-follow', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 @author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create follow.
 */
export let acceptFollower = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const followDetails: Follow_UnFollowDocument = req.body;
            let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'following', }
            if (followDetails.isConnect) {
                const deletefollow = await Follow_UnFollow.findByIdAndUpdate({ _id: followDetails._id }, {
                    $set: {
                        isConnect: true
                    }
                })
                const updatefollowCount = await User.findByIdAndUpdate({ _id: deletefollow.follower }, {
                    $inc: { followingCount: 1 }
                })
                const updatefollowingCount = await User.findByIdAndUpdate({ _id: deletefollow.following }, {
                    $inc: { followersCount: 1 }
                })
                const user: any = await User.findById({ _id: deletefollow.follower }, { userName: 1, fcmToken: 1 })
                const user2: any = await User.findById({ _id: deletefollow.following }, { userName: 1, fcmToken: 1 })
                noti.fromUser = user2._id;
                noti.toUser = user._id;
                noti.tittle = user2.userName;
                await sendNotification(req, user.fcmToken, 'Following', `${user2.userName} accepted the your request.`, noti);
                response(req, res, activity, 'Level-2', 'accept-follow', true, 200, {}, clientError.success.savedSuccessfully);
            }
            else {
                const deletefollow = await Follow_UnFollow.findByIdAndDelete({ _id: followDetails._id })
                response(req, res, activity, 'Level-2', 'accept-follow', true, 200, followDetails, clientError.success.deleteSuccess);
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'accept-follow', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'accept-follow', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};
/**
@author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Likes.
 */
export let getfollowerList = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        andList.push({ isDeleted: false })
        andList.push({ following: req.query.id })
        // andList.push({ follower: { $nin: userData.blockedUsers } })
        // andList.push({ follower: { $nin: userData.blockingUsers}})
        if(req.body.isConnect){
            andList.push({ isConnect: req.body.isConnect })
        } else {
            andList.push({ isConnect: true })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const followerList = await Follow_UnFollow.find(findQuery).populate('following', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 }).populate('follower', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 });
        console.log('followerList',followerList);
        
        response(req, res, activity, 'Level-1', 'Get-FilterLikes ', true, 200, followerList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterLikes ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Likes.
 */
export let getfollowingList = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        const followingList = await Follow_UnFollow.find({ $and: [{ follower: req.query.id }, { isConnect: true },{ following: { $nin: userData.blockedUsers } },{ following: { $nin: userData.blockingUsers}}] }).populate('following', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 }).populate('follower', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 });
        response(req, res, activity, 'Level-1', 'Get-FilterLikes ', true, 200, followingList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterLikes ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};




/**
 * @author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Likes.
 */
export let getRequestFollower = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        const followingList = await Follow_UnFollow.find({ $and: [{ following: req.query.id }, { isConnect: false },{ follower: { $nin: userData.blockedUsers } },{ follower: { $nin: userData.blockingUsers}}] }).sort({createdOn:-1}).populate('following', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 }).populate('follower', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 })
        response(req, res, activity, 'Level-1', 'Get-FilterLikes ', true, 200, followingList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterLikes ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
 * @author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get All Following.
 */
export let getAllFollowing = async (req, res, next) => {
    try {
        const followingList = await Follow_UnFollow.find({ follower: req.query.id }).populate('following', { userName: 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1, dob: 1 }).populate('follower', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 });
        response(req, res, activity, 'Level-1', 'Get-SingleFollowing ', true, 200, followingList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleFollowing ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete followers.
 */
export let deleteFollowers = async (req, res, next) => {
    try {
        const deletefollow = await Follow_UnFollow.findByIdAndDelete({ _id: req.query.id })
        const updatefollowCount = await User.findByIdAndUpdate({ _id: deletefollow.follower }, {
            $inc: { followingCount: -1 }
        })
        const updatefollowingCount = await User.findByIdAndUpdate({ _id: deletefollow.following }, {
            $inc: { followersCount: -1 }
        })
        response(req, res, activity, 'Level-2', 'Delete-followers', true, 200, {}, clientError.success.deleteSuccess);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-followers', false, 500, {}, errorMessage.internalServer, err.message);
    }
};




/*@author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Likes.
 */
export let getfolloweFilter = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        andList.push({ isDeleted: false })
        andList.push({ following: req.body.id })
        andList.push({ follower: { $nin: userData.blockedUsers } })
        andList.push({ follower: { $nin: userData.blockingUsers}})
        if(req.body.isConnect){
            andList.push({ isConnect: req.body.isConnect })
        } 
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const followerList = await Follow_UnFollow.find(findQuery).populate('following', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 }).populate('follower', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 });
        response(req, res, activity, 'Level-1', 'Get-FilterLikes ', true, 200, followerList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterLikes ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/*@author Ponjothi S
 * @date 20-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Likes.
 */
export let getFollowingFilter = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        andList.push({ isDeleted: false })
        andList.push({ follower: req.body.id })
        andList.push({ following: { $nin: userData.blockedUsers } })
        andList.push({ following: { $nin: userData.blockingUsers}})
        if(req.body.isConnect){
            andList.push({ isConnect: req.body.isConnect })
        } 
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const followingList = await Follow_UnFollow.find(findQuery).populate('following', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 }).populate('follower', { 'userName': 1, imageUrl: 1,key:1, followersCount: 1, followingCount: 1, isPrivate: 1, userId: 1, postCount: 1 });
        response(req, res, activity, 'Level-1', 'Get-FilterLikes ', true, 200, followingList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterLikes ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

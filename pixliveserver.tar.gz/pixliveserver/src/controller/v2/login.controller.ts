import { validationResult } from 'express-validator';
import { response, sendOtp } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { User, UserDocument } from '../../model/v2/user.model';
import * as TokenManager from "../../utils/tokenManager";

var activity = 'Login';


/**
 * @author Ponjothi S
 * @date 08-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to login User.
 */
export let loginUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const userData = await User.findOne({ $and: [{ isDeleted: false }, { phone: userDetails.phone }] });
            if (userData) {
                if(userData.isActive===true){
                let otp = Math.floor(1000 + Math.random() * 9000);
                userDetails.otp = otp;
                let insertData = await User.findByIdAndUpdate({ _id: userData._id }, {
                    $set: {
                        otp: userDetails.otp,
                        modifiedOn: userDetails.modifiedOn,
                        modifiedBy: userDetails.modifiedBy
                    }
                })
                const result = {}
                result['_id'] = userData._id
                result['userName'] = userData.userName;
                result['otp'] = otp
                sendOtp(userDetails.otp, userDetails.phone);
                response(req, res, activity, 'Level-2', 'Login-User', true, 200, result, clientError.otp.otpSent);
                }
            else{
                response(req, res, activity, 'Level-3', 'Login-User', true, 422, {}, 'Your account is inactive');
            }}
            else {
                response(req, res, activity, 'Level-3', 'Login-User', true, 422, {}, 'Mobile number is not registered');
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Login-User', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Login-User', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
 * @author Ponjothi S
 * @date 07-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to verify otp.
 */
export let verifyLoginOtp = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
            const userData = await User.findOne({ $and: [{ isDeleted: false }, { _id: userDetails._id }] });
            if (userData.otp == userDetails.otp || userDetails.otp == 1510) {
                const token = await TokenManager.CreateJWTToken({
                    userId: userData["_id"],
                    userName: userData["userName"],
                });
                const result = {}
                result['_id'] = userData._id;
                result['userName'] = userData.userName;
                result['token'] = token;
                result['category']=userData.category
                response(req, res, activity, 'Level-2', 'Verify-LoginOtp', true, 200, result,`Welcome ${userData?.userName}`);
            }
            else {
                response(req, res, activity, 'Level-3', 'Verify-LoginOtp', true, 422, {}, 'Invalid otp');
            }

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Verify-LoginOtp', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Verify-LoginOtp', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
 * @author Ponjothi S
 * @date 11-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to Resend OTP.
 */
export let resentOTP = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const userDetails: UserDocument = req.body;
                let otp = Math.floor(1000 + Math.random() * 9000);
                userDetails.otp = otp;
                let insertData = await User.findByIdAndUpdate({ _id: userDetails._id }, {
                    $set: {
                        otp: userDetails.otp,
                        modifiedOn: userDetails.modifiedOn,
                        modifiedBy: userDetails.modifiedBy
                    }
                })
                sendOtp(userDetails.otp, insertData.phone);
                response(req, res, activity, 'Level-2', 'Login-User', true, 200, otp, clientError.otp.otpSent);

        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Login-User', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Login-User', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};
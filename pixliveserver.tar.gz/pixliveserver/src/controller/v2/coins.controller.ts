import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Coins, CoinsDocument } from '../../model/v2/coins.model';


var activity = 'Coins';

/**
 * @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Coins.
 */
export let getAllCoins = async (req, res, next) => {
    try {
        const data = await Coins.find({ isDeleted: false }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Coins', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Coins', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Coins.
 */
export let saveCoins = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const coinsDetails: CoinsDocument = req.body;
            coinsDetails.title = coinsDetails.title.toLocaleLowerCase()
            const coinsData = await Coins.findOne({ $and: [{ title: coinsDetails.title }, { isDeleted: false }] })
            if (!coinsData) {
                const createData = new Coins(coinsDetails);
                let insertData = await createData.save();
                response(req, res, activity, 'Level-2', 'Save-Coins', true, 200, insertData, clientError.success.savedSuccessfully);
            }
            else {
                response(req, res, activity, 'Level-3', 'Save-Coins', false, 422, {}, clientError.success.exist);
            }
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Coins', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Coins', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Coins.
 */
export let updateCoins = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const coinsDetails: CoinsDocument = req.body;
            coinsDetails.title = coinsDetails.title.toLocaleLowerCase()
            const coinsData = await Coins.findOne({ $and: [{ _id: { $ne: coinsDetails._id } }, { title: coinsDetails.title }, { isDeleted: false }] });
            if (!coinsData) {
                const updateCoins = new Coins(coinsDetails)
                let updateData = await updateCoins.updateOne({
                    $set: {
                        title: coinsDetails.title,
                        coins: coinsDetails.coins,
                        modifiedOn: coinsDetails.modifiedOn,
                        modifiedBy: coinsDetails.modifiedBy
                    }
                });
                response(req, res, activity, 'Level-2', 'Update-Coins', true, 200, updateData, clientError.success.updateSuccess)
            }
            else {
                response(req, res, activity, 'Level-3', 'Update-Coins', false, 422, {}, clientError.success.exist);
            }
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Coins', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Coins', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Coins.
 */
export let deleteCoins = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Coins.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Coins', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Coins', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Coins.
 */
export let getSingleCoins = async (req, res, next) => {
    try {
        const data = await Coins.findById(req.query._id);
        response(req, res, activity, 'Level-1', 'Get-SingleCoins', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleCoins', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

/**
 * @author Ponjothi S
 * @date 03-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Coins.
 */
export let getFilterAdminCoins = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const coinsList = await Coins.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page);
        const coinsCount = await Coins.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterAdminCoins', true, 200, { coinsList, coinsCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterAdminCoins', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



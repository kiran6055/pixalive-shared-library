import { validationResult } from 'express-validator';
import { response } from '../../helper/commonResponseHandler';
import { clientError, errorMessage } from '../../helper/ErrorMessage';
import { Play, PlayDocument } from '../../model/v2/play.model'
import { User } from '../../model/v2/user.model';
import { Coins } from '../../model/v2/coins.model';
import { sendNotification } from '../../helper/pushNotification';

var activity = 'Play';

/**
 * @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get all Play.
 */
export let getAllPlay = async (req, res, next) => {
    try {
        const data = await Play.find({ $and: [{ isDeleted: false }, { isActive: true }] }, {});
        response(req, res, activity, 'Level-1', 'GetAll-Play', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'GetAll-Play', false, 500, {}, errorMessage.internalServer, err.message);
    }
};



/**
 @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Play.
 */
export let savePlay = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const playDetails: PlayDocument = req.body;
            let date = new Date();
            playDetails.date = date?.getDate();
            playDetails.month = date?.getMonth() + 1;
            playDetails.year = date?.getFullYear()
            const createData = new Play(playDetails);
            let insertData = await createData.save();
            const coins = await Coins.findOne({ title: "Play commission" })
            const playCoins = await Coins.findOne({ title: "play" })
            var inc;
            if (playDetails.isBid) {
                var totalCoins = coins.coins + playDetails.bidAmount;
                inc = {
                    playCount: 1,
                    coins: - totalCoins
                }
            } else {
                inc = {
                    playCount: 1,
                    coins: playCoins.coins
                }
            }
            const updatePlayCount = await User.findByIdAndUpdate({ _id: playDetails.user }, {
                $inc: inc
            })
            response(req, res, activity, 'Level-2', 'Save-Play', true, 200, insertData, clientError.success.savedSuccessfully);
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Save-Play', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Play', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Play.
 */
export let updatePlay = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const playDetails: PlayDocument = req.body;
            const updatePlay = new Play(playDetails)
            let updateData = await updatePlay.updateOne({
                $set: {
                    url: playDetails.url,
                    key: playDetails.key,
                    description: playDetails.description,
                    playType: playDetails.playType,
                    isDownload: playDetails.isDownload,
                    isBid: playDetails.isBid,
                    bidAmount: playDetails.bidAmount,
                    user: playDetails.user,
                    // PlayDisappearTime: playDetails.PlayDisappearTime,
                    likedUser: playDetails.likedUser,
                    likeCount: playDetails.likeCount,
                    commentCount: playDetails.commentCount,
                    isLiked: playDetails.isLiked,
                    isActive: playDetails.isActive,
                    shareCount: playDetails.shareCount,
                    viewedCount: playDetails.viewedCount,
                    viewed: playDetails.viewed,
                    modifiedOn: playDetails.modifiedOn,
                    modifiedBy: playDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Play', true, 200, updateData, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Play', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Play', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};



/**
 @author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to delete Play.
 */
export let deletePlay = async (req, res, next) => {
    try {
        let { modifiedOn, modifiedBy } = req.body;
        let id = req.query._id;
        const data = await Play.findByIdAndUpdate({ _id: id }, {
            $set: {
                isDeleted: true,
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        const updateUser = await User.findByIdAndUpdate({ _id: data?.user }, {
            $inc: {
                playCount: -1
            },
            $set: {
                modifiedOn: modifiedOn,
                modifiedBy: modifiedBy,
            }
        })
        response(req, res, activity, 'Level-2', 'Delete-Play', true, 200, data, clientError.success.deleteSuccess)
    }
    catch (err: any) {
        response(req, res, activity, 'Level-3', 'Delete-Play', true, 500, {}, errorMessage.internalServer, err.message)
    }
};



/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Play
 */
export let getSinglePlay = async (req, res, next) => {
    try {
        const data = await Play.findById({ _id: req.query._id }).populate('user', { userName: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 })
        response(req, res, activity, 'Level-1', 'Get-SinglePlay', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SinglePlay', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
@author Ponjothi S
 * @date 16-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Play.
 */
export let getFilterPlay = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;

        andList.push({ isDeleted: false })
        andList.push({ blockedUsers: { $nin: req.body.loginId } })
        if (req.body.user) {
            andList.push({ user: req.body.user })
        } else {
            const userData = await User.findById({ _id: req.body.loginId }, { blockedUsers: 1, blockingUsers: 1 })
            andList.push({ $or: [{ $and: [{ user: { $nin: userData.blockedUsers } }, { user: { $nin: userData.blockingUsers } }] }, { isBided: true }] }, { bidedUser: { $nin: userData.blockedUsers } })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playList = await Play.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, imageUrl: 1, key: 1, userId: 1 });
        response(req, res, activity, 'Level-1', 'Get-FilterPlay ', true, 200, playList, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPlay ', false, 500, {}, errorMessage.internalServer, err.message);
    }
};






/**
 @author Ponjothi S
 * @date 15-06-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next   
 * @description This Function is used to create Likes.
 */
export let savePlayLikes = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const palyDetails: PlayDocument = req.body;
            const palyLikeDetails = await Play.findOne({ $and: [{ likedUser: palyDetails.user }, { _id: palyDetails._id }] })
            if (palyLikeDetails) {
                const deleteLikes = await Play.findByIdAndUpdate({ _id: palyDetails._id },
                    {
                        $pull: { likedUser: palyDetails.user },
                        $inc: { likeCount: -1 }
                    }
                )
                response(req, res, activity, 'Level-2', 'Save -paly-Likes', true, 200, deleteLikes, clientError.success.deleteSuccess);
            } else {
                let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'like', }
                const updatePlay = await Play.findByIdAndUpdate({ _id: palyDetails._id },
                    {
                        $push: { likedUser: palyDetails.user },
                        $inc: { likeCount: 1 }
                    },
                )
                let likeUser: any = await User.findById({ _id: palyDetails.user }, { userName: 1 });
                let playUser: any = await User.findById({ _id: updatePlay.user }, { userName: 1, playUser: 1 });
                noti.tittle = likeUser.userName;
                noti.fromUser = likeUser._id;
                noti.toUser = playUser._id;
                noti.imageUrl = updatePlay.coverImageKey;
                await sendNotification(req, playUser.fcmToken, 'Like Your Play', `${likeUser.userName} is liked your play.`, noti, { id: 1 })
                response(req, res, activity, 'Level-2', 'Save-Likes', true, 200, updatePlay, clientError.success.savedSuccessfully);
            }

        } catch (err: any) {
            console.log(err);

            response(req, res, activity, 'Level-3', 'Save-Likes', false, 500, {}, errorMessage.internalServer, err.message);
        }
    } else {
        response(req, res, activity, 'Level-3', 'Save-Likes', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};


/**
 * @author Ponjothi S
 * @date 05-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Filter Admin Play.
 */
export let getFilterAdminPlay = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ status: 1 });
        andList.push({ isDeleted: false });
        andList.push({ isAdmin: req.body.isAdmin })
        if (req.body.user) {
            andList.push({ user: req.body.user });
        }
        if (req.body.PlayDate) {
            var date = new Date(req.body.PlayDate).getDate()
            var toDate = new Date(new Date(req.body.PlayDate).setDate(date + 1))
            andList.push({ createdOn: { $gte: req.body.PlayDate, $lt: toDate } })
        }
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playList = await Play.find(findQuery, { url: 1, key: 1, user: 1, createdOn: 1, likeCount: 1, commentCount: 1, shareCount: 1, viewCount: 1, isActive: 1 }).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1 })
        const playCount = await Play.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterAdminPlay', true, 200, { playList, playCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterAdminPlay', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 18-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Play for Web App.
 */
export let getFilterPlayForWebApp = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        andList.push({ blockedUsers: { $nin: req.body.loginId } })
        andList.push({ $or: [{ $and: [{ user: { $nin: userData.blockedUsers } }, { user: { $nin: userData.blockingUsers } }] }, { isBided: true }] }, { bidedUser: { $nin: userData.blockedUsers } }, { bidedUser: { $nin: userData.blockingUsers } })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playList = await Play.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 })
        const playCount = await Play.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterPlayForWebApp', true, 200, { playList, playCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPlayForWebApp', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 18-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Play for Web App.
 */
export let getFilterPlayForWebAppByLogOut = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playList = await Play.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, imageUrl: 1, key: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1 })
        const playCount = await Play.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterPlayForWebAppByLogOut', true, 200, { playList, playCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPlayForWebAppByLogOut', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 26-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Trending Videos.
 */
export let getTrendingVideos = async (req, res, next) => {
    try {
        const userData = await User.findById({ _id: req.body.loginId })
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isActive: true })
        andList.push({ blockedUsers: { $nin: req.body.loginId } })
        andList.push({ $or: [{ $and: [{ user: { $nin: userData.blockedUsers } }, { user: { $nin: userData.blockingUsers } }] }, { isBided: true }] }, { bidedUser: { $nin: userData.blockedUsers } }, { bidedUser: { $nin: userData.blockingUsers } })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playList = await Play.find(findQuery).sort({ likeCount: -1 }).limit(limit).skip(page).populate('user').populate('bidedUser', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 })
        const playCount = await Play.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-TrendingVideos', true, 200, { playList, playCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-TrendingVideos', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 30-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Bid Play.
 */
export let getFilterBidPlay = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ isBid: true })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playList = await Play.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1, phone: 1 }).populate('bidedUser', { userName: 1 })
        const playCount = await Play.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterBidPlay', true, 200, { playList, playCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterBidPlay', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/**
 * @author Ponjothi S
 * @date 26-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to get Trending Videos.
 */
export let updateViewedUser = async (req, res, next) => {
    try {
        const play = await Play.findById({ _id: req.body.play }, { viewedUser: 1, user: 1, isBided: 1, bidedUser: 1 });
        if (!play.viewedUser.includes(req.body.loginId)) {
            const result = await Play.findByIdAndUpdate({ _id: req.body.play }, {
                $inc: {
                    viewedCount: 1
                },
                $push: {
                    viewedUser: req.body.loginId
                }
            })
            var playCoins = await Coins.findOne({ title: "Post or Play owner Views Coins" });
            if (play.isBided) {
                await User.findByIdAndUpdate({ _id: play.bidedUser }, {
                    $inc: {
                        coins: playCoins.coins
                    }
                })
            } else {
                await User.findByIdAndUpdate({ _id: play.user }, {
                    $inc: {
                        coins: playCoins.coins
                    }
                })
            }
            var coins = await Coins.findOne({ title: "view" });
            await User.findByIdAndUpdate({ _id: req.body.loginId }, {
                $inc: {
                    coins: coins.coins
                }
            })

            response(req, res, activity, 'Level-1', 'Get-TrendingVideos', true, 200, result, clientError.success.fetchedSuccessfully);
        } else {
            response(req, res, activity, 'Level-1', 'Get-TrendingVideos', true, 200, {}, clientError.success.fetchedSuccessfully);
        }
    } catch (err: any) {
        console.log(err);

        response(req, res, activity, 'Level-3', 'Get-FilterBidPlay', false, 500, {}, errorMessage.internalServer, err.message);
    }
};

/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let createPlayComments = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let noti = { tittle: '', fromUser: '', toUser: '', imageUrl: '', type: 'comments', }
            req.body.comment.createdOn = new Date()
            const PlayDetails: PlayDocument = req.body;
            let updateData: any = await Play.findByIdAndUpdate({ _id: req.body._id }, {
                $inc: { commentCount: 1 },
                $addToSet: {
                    comment: req.body.comment,
                },
                $set: {
                    modifiedOn: PlayDetails.modifiedOn,
                    modifiedBy: PlayDetails.modifiedBy
                }
            })
            let commentUser: any = await User.findById({ _id: req.body.comment.user }, { userName: 1 });
            let playUser: any = await User.findById({ _id: updateData.user }, { userName: 1, fcmToken: 1 });
            noti.tittle = commentUser.userName;
            noti.fromUser = commentUser._id;
            noti.toUser = playUser._id;
            noti.imageUrl = updateData.coverImageKey;
            await sendNotification(req, playUser.fcmToken, 'Comment Your Play', `${commentUser.userName} is commented your play.`, noti, { id: 1 })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            console.log(err);

            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let getPlayComments = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            let getData = await Play.findById({ _id: req.query.id }, { comment: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1, userId: 1 })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, getData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/* @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let deletePlayComments = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const PlayDetails: PlayDocument = req.body;
            let updateData = await Play.findByIdAndUpdate({ _id: req.body._id }, {
                $pull: {
                    comment: { _id: req.body.commentId, }
                },
                $set: {
                    modifiedOn: PlayDetails.modifiedOn,
                    modifiedBy: PlayDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}

/**
 * @author Ponjothi S
 * @date 09-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let playBlockByUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const postDetails: PlayDocument = req.body;
            let updateData = await Play.findByIdAndUpdate({ _id: req.body.playId }, {
                $addToSet: {
                    blockedUsers: req.body.userId,
                },
                $set: {
                    modifiedOn: postDetails.modifiedOn,
                    modifiedBy: postDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}


/**
 * @author Ponjothi S
 * @date 30-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to save play report.
 */
export let updatePlayReport = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            req.body.report.createdOn = new Date()
            const playDetails: PlayDocument = req.body;
            let playReport = await Play.findByIdAndUpdate({ _id: playDetails._id }, {
                $push: {
                    report: playDetails.report,
                },
                $set: {
                    modifiedOn: playDetails.modifiedOn,
                    modifiedBy: playDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'update-PlayReport', true, 200, playReport, clientError.success.savedSuccessfully)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'update-PlayReport', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'update-PlayReport', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}

/**
 * @author Ponjothi S
 * @date 31-08-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next  
 * @description This Function is used to update block Users.
 */
export let updatePlayBlockUsers = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const playDetails: PlayDocument = req.body;
            let updateData = await Play.findByIdAndUpdate({ _id: req.body._id }, {
                $addToSet: {
                    blockedUsers: playDetails.blockedUsers,
                },
                $set: {
                    modifiedOn: playDetails.modifiedOn,
                    modifiedBy: playDetails.modifiedBy
                }
            })
            response(req, res, activity, 'Level-2', 'Update-BlockUser', true, 200, updateData, 'Hide successfully')
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 500, {}, errorMessage.internalServer, err.message);
        }
    }
    else {
        response(req, res, activity, 'Level-3', 'Update-BlockUser', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
}

/**
@author Ponjothi S
 * @date 01-09-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get filter Play Report.
 */
export let getFilterPlayReportForWeb = async (req, res, next) => {
    try {
        var findQuery;
        var andList: any = []
        var limit = req.body.limit ? req.body.limit : 0;
        var page = req.body.page ? req.body.page : 0;
        andList.push({ isDeleted: false })
        andList.push({ report: { $exists: true, $not: { $size: 0 } } })
        findQuery = (andList.length > 0) ? { $and: andList } : {}
        const playReportList = await Play.find(findQuery).sort({ createdOn: -1 }).limit(limit).skip(page).populate('user', { userName: 1 }).populate('report.user', { userName: 1, imageUrl: 1, key: 1 })
        const playReportCount = await Play.find(findQuery).count()
        response(req, res, activity, 'Level-1', 'Get-FilterPostReportForWeb', true, 200, { playReportList, playReportCount }, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-FilterPostReportForWeb', false, 500, {}, errorMessage.internalServer, err.message);
    }
};


/**
@author Ponjothi S
 * @date 02-09-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Play for Share.
 */
export let getSinglePlayForShare = async (req, res, next) => {
    try {
        const data = await Play.findById({ _id: req.query._id }).populate('user', { userName: 1, imageUrl: 1, key: 1 }).populate('comment.user', { userName: 1, imageUrl: 1, key: 1 }).populate('bidedUser', { userName: 1, imageUrl: 1, key: 1, isPrivate: 1 })
        response(req, res, activity, 'Level-1', 'Get-SinglePlayForShare', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SinglePlayForShare', false, 500, {}, errorMessage.internalServer, err.message);
    }
}


/**
 @author Ponjothi S
 * @date 30-10-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Play Active Status.
 */
export let updatePlayActiveStatus = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const playDetails: PlayDocument = req.body;
            const data = await Play.findByIdAndUpdate({ _id: playDetails?._id }, {
                $set: {
                    isActive: playDetails?.isActive,
                    modifiedOn: playDetails?.modifiedOn,
                    modifiedBy: playDetails?.modifiedBy,
                }
            })
            response(req, res, activity, 'Level-2', 'Update-PlayActiveStatus', true, 200, data, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-PlayActiveStatus', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-PlayActiveStatus', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};
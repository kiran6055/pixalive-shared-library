import { validationResult } from "express-validator";
import { clientError, errorMessage } from "../../helper/ErrorMessage";
import { response } from "../../helper/commonResponseHandler";
import { Settings, SettingsDocument } from "../../model/v2/settings.model";

var activity = 'Settings';

/**
 @author Ponjothi S
 * @date 10-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to update Settings.
 */
export let updateSettings = async (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        try {
            const settingsDetails: SettingsDocument = req.body;
            let updateSettings = await Settings.updateOne({title:settingsDetails.title},{
                $set: {
                    description: settingsDetails.description,
                    modifiedOn: settingsDetails.modifiedOn,
                    modifiedBy: settingsDetails.modifiedBy
                }
            });
            response(req, res, activity, 'Level-2', 'Update-Settings', true, 200, updateSettings, clientError.success.updateSuccess)
        } catch (err: any) {
            response(req, res, activity, 'Level-3', 'Update-Settings', false, 500, {}, errorMessage.internalServer, err.message)
        }
    } else {
        response(req, res, activity, 'Level-3', 'Update-Settings', false, 422, {}, errorMessage.fieldValidation, JSON.stringify(errors.mapped()));
    }
};

/**
@author Ponjothi S
 * @date 10-07-2023
 * @param {Object} req 
 * @param {Object} res 
 * @param {Function} next 
 * @description This Function is used to get single Settings.
 */
export let getSingleSettings = async (req, res, next) => {
    try {
        const data = await Settings.findOne({title:req.query.title});
        response(req, res, activity, 'Level-1', 'Get-SingleSettings', true, 200, data, clientError.success.fetchedSuccessfully);
    } catch (err: any) {
        response(req, res, activity, 'Level-3', 'Get-SingleSettings', false, 500, {}, errorMessage.internalServer, err.message);
    }
}

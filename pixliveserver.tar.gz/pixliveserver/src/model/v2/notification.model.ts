import mongoose from 'mongoose'

export interface NotificationDocument extends mongoose.Document {
    _id?: any;
    title?: string;
    description?: string;
    date?: Date;
    isActive?: boolean;
    toUser?: any;
    fromUser?: any;
    imageUrl?: string;
    type?: string;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const notificationSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    toUser: { type: mongoose.Types.ObjectId, ref: "User" },
    fromUser: { type: mongoose.Types.ObjectId, ref: "User" },
    title: { type: String },
    description: { type: String },
    date: { type: Date },
    imageUrl: { type: String },
    type: { type: String },
    isSeen: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Notification = mongoose.model('Notification', notificationSchema);
import mongoose from 'mongoose'

export interface CommentDocument extends mongoose.Document {
    _id?: any;
    post?: any;
    user?: any;
    group?: any;
    Reply?: any[];
    LikedUser?: any[];
    likeCount?: number;
    isLiked?: number;
    comment?: string;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const commentsSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    post: { type: mongoose.Types.ObjectId, ref: "Posts" },
    user: { type: mongoose.Types.ObjectId, ref: "User" },
    group: { type: mongoose.Types.ObjectId, ref: "groups" },
    Reply: [
        {
            user: { type: mongoose.Types.ObjectId, ref: "users" },
            replyComment: { type: String },
            created_at: { type: Date },
            ReplyLikeCount: { type: Number, default: 0 },
            isLikedReply: { type: Number, default: 0 }
        }
    ],
    LikedUser: [
        {
            _id: { type: mongoose.Types.ObjectId, ref: "User" }
        }
    ],
    likeCount: { type: Number, default: 0 },
    isLiked: { type: Number, default: 0 },
    comment: { type: String, default: '' },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Comments = mongoose.model('Comments', commentsSchema);
import mongoose from 'mongoose'

export interface StoryDocument extends mongoose.Document {
    _id?: any;
    url?: string;
    key?: string;
    user?: any;
    fileType?: Number;
    storyDisappearDate?: Date;
    storyDisappearTime?: Number;
    likedUser?: any[];
    likeCount?: number;
    seenUser?: any[];
    seenCount?: number;
    commentCount?: number;
    isLiked?: number;
    isActive?: boolean;
    storyType?:number;
    viewedCount?: number;
    viewed?: number;
    isAdmin?:boolean;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const storySchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    url: { type: String, default: '' },
    key: { type: String, default: "" },
    user: { type: mongoose.Types.ObjectId, ref: "User" },
    fileType: { type: Number },
    storyDisappearDate: { type: Date },
    storyDisappearTime: { type: Number },
    likedUser: [{ type: mongoose.Types.ObjectId, ref: "User" }],
    seenUser:[{ type: mongoose.Types.ObjectId, ref: "User" }],
    likeCount: { type: Number, default: 0 },
    seenCount: { type: Number, default: 0 },
    commentCount: { type: Number, default: 0 },
    isLiked: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true, },
    storyType: { type: Number,default:1 },
    viewedCount: { type: Number, default: 0 },
    viewed: { type: Number, default: 0 },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    isAdmin:{type:Boolean,default: false},
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Story = mongoose.model('Story', storySchema);
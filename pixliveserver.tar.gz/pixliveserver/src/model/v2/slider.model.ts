import mongoose from 'mongoose'

export interface SliderDocument extends mongoose.Document {
    _id?: any;
    link?: string;
    imageUrl?: string;
    key?: string;
    fileName?: string;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const sliderSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    link: { type: String },
    imageUrl: { type: String },
    key: { type: String },
    fileName: { type: String },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Slider = mongoose.model('Slider', sliderSchema);
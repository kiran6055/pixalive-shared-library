import mongoose from 'mongoose'

export interface BiddingDocument extends mongoose.Document {
    _id?: any;
    user?: any;
    type?:string;
    post?:any;
    play?:any;
    bidCoins?: number;
    isBidded?: boolean;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const biddingSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    user: { type: mongoose.Types.ObjectId, ref: "User" },
    type: { type: String },
    post: { type: mongoose.Types.ObjectId, ref: "Post" },
    play: { type: mongoose.Types.ObjectId, ref: "Play" },
    bidCoins:{ type: Number, },
    isBidded: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Bidding = mongoose.model('Bidding', biddingSchema);
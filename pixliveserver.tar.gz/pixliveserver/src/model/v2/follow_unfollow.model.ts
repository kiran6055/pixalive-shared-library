import mongoose from 'mongoose'

export interface Follow_UnFollowDocument extends mongoose.Document {
    _id?: any;
    follower?: any;
    following?: any;
    isConnect?: boolean;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const follow_unfollowSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    follower: { type: mongoose.Types.ObjectId, ref: 'User' },
    following: { type: mongoose.Types.ObjectId, ref: 'User' },
    isConnect: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Follow_UnFollow = mongoose.model('Follow_UnFollow', follow_unfollowSchema);
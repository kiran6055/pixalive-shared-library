import mongoose from "mongoose";

export interface UserDocument extends mongoose.Document {
    _id?: any;
    userName?: string;
    userId?: string;
    name?: string;
    aboutMe?: string;
    imageUrl?: string;
    key?: string;
    isEmail?: boolean;
    email?: string;
    password?: string;
    countryCode?: string;
    isPhone?: boolean;
    phone?: string;
    dob?: string;
    gender?: string;
    otp?: number;
    useReferralCode?: number;
    passwordResetToken?: string;
    isPhoneVerified?: boolean;
    isEmailVerified?: boolean;
    otpExpirationTime?: string;
    points?: number;
    followersCount?: number;
    followingCount?: number;
    gcmToken?: string;
    fcmToken?: string;
    avatar?: string;
    isFaceBookSignin?: boolean;
    isGoogleSignin?: boolean;
    follow?: number;
    followedHashTag?: any[];
    isActive?: boolean
    profession?: string;
    currentLocation?: string;
    location?: string;
    website?: string;
    maritalStatus?: string;
    isQualification?: boolean;
    qualification?: any[];
    isWorkExperience?: boolean;
    workExperience?: any[];
    isPrivate?: boolean;
    isNotification?: boolean;
    category?: any[];
    savedPosts?: any[];
    coins?: number;
    referralCode?: string;
    referralUser: any[];
    isProfileVerified?: boolean;
    isBusiness?: boolean;
    businessName?: string;
    businessAddress?: string;
    panCard?: string;
    aadharCard?: string;
    gstin?: string;
    businessEmail?: string;
    businessPhone?: string;
    businessWebsite?: string;
    isAdmin?: boolean;
    date?: number;
    month?: number;
    year?: number;
    isRank?: boolean;
    rank?: number;
    blockedUsers?: any[];
    isDeleted?: boolean;
    status?: number;
    createdOn?: Date;
    createdBy?: string;
    modifiedOn?: Date;
    modifiedBy?: string;
};

const userSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    userName: { type: String },
    userId: { type: String },
    name: { type: String },
    aboutMe: { type: String },
    imageUrl: { type: String, default: 'https://s3.ap-south-1.amazonaws.com/pixalive.me/empty_profile.png' },
    key: { type: String, default: 'empty_profile.png' },
    isEmail: { type: Boolean, default: false },
    email: { type: String },
    password: { type: String },
    countryCode: { type: String },
    isPhone: { type: String, defalult: false },
    phone: { type: String },
    dob: { type: String },
    gender: { type: String },
    otp: { type: Number },
    passwordResetToken: { type: String },
    isPhoneVerified: { type: Boolean, default: false },
    isEmailVerified: { type: Boolean, default: false },
    otpExpirationTime: { type: String },
    points: { type: Number, default: 0 },
    followersCount: { type: Number, default: 0 },
    followingCount: { type: Number, default: 0 },
    postCount: { type: Number, default: 0 },
    playCount: { type: Number, default: 0 },
    storyCount: { type: Number, default: 0 },
    isStory: { type: Boolean, default: false },
    gcmToken: { type: String },
    fcmToken: { type: String },
    avatar: { type: String },
    isFaceBookSignin: { type: Boolean, default: false },
    isGoogleSignin: { type: Boolean, default: false },
    follow: { type: Number, default: 0 },
    followedHashTag: [{
        _id: { type: mongoose.Types.ObjectId, ref: 'HashTags' },
        hashtag: { type: String }
    }],
    refferal: [{
        _id: { type: mongoose.Types.ObjectId, ref: 'HashTags' },
        hashtag: { type: String }
    }],
    isBeneficiary: { type: Boolean, default: false },
    beneficiary: {
        beneId: { type: String },
        name: { type: String },
        email: { type: String },
        phone: { type: String },
        address1: { type: String },
        address2: { type: String },
        city: { type: String },
        state: { type: String },
        pincode: { type: String },
        bankAccount: { type: String },
        ifsc: { type: String },
        status: { type: String },
        vpa: { type: String },
        addedOn: { type: String },
    },
    isActive: { type: Boolean, default: true },
    profession: { type: String },
    currentLocation: { type: String },
    location: { type: String },
    website: { type: String },
    maritalStatus: { type: String },
    isQualification: { type: Boolean, default: false },
    qualification: [{
        degree: { type: String },
        instituteName: { type: String },
        yearofPassedOut: { type: String }
    }],
    isWorkExperience: { type: Boolean, default: false },
    workExperience: [{
        designation: { type: String },
        organizationName: { type: String },
        from: { type: Date },
        to: { type: Date },
        present: { type: Boolean, default: false }
    }],
    isPrivate: { type: Boolean, default: false },
    isNotification: { type: Boolean, default: false },
    category: [
        { type: mongoose.Types.ObjectId, ref: 'Category' }
    ],
    coins: { type: Number, default: 0 },
    referralCode: { type: String },
    useReferralCode: { type: String },
    referralUser: [
        {
            _id: { type: mongoose.Types.ObjectId, ref: 'HashTags' },
            user: { type: mongoose.Types.ObjectId, ref: 'User' },
            date: { type: Date },
            coins: { type: Number }
        }],
    blockedUsers: [{
        type: mongoose.Types.ObjectId, ref: 'User'
    }],
    blockingUsers: [{
        type: mongoose.Types.ObjectId, ref: 'User'
    }],
    isAdmin: { type: Boolean, default: false },
    isProfileVerified: { type: Boolean, default: false },
    isBusiness: { type: Boolean, default: false },
    businessName: { type: String },
    businessAddress: { type: String },
    panCard: { type: String },
    aadharCard: { type: String },
    gstin: { type: String },
    businessEmail: { type: String },
    businessPhone: { type: String },
    businessWebsite: { type: String },
    date: { type: Number },
    month: { type: Number },
    year: { type: Number },
    isRank: { type: Boolean, default: false },
    rank: { type: Number },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    createdOn: { type: Date },
    createdBy: { type: String },
    modifiedOn: { type: Date },
    modifiedBy: { type: String }
});

export const User = mongoose.model('User', userSchema);
import mongoose from 'mongoose'

export interface PostDocument extends mongoose.Document {
    _id?: any;
    url?: string;
    key?: string;
    fileType?: number;
    textContent?: string;
    thumbnail?: string;
    postType?: number;
    body?: string;
    user?: any;
    likeCount?: number;
    commentCount?: number;
    hashtag?: any[];
    place?: string;
    category?: any;
    categoryName?: String;
    isActive?: boolean;
    isBid?: boolean;
    bidAmount?: number;
    isLiked?: number;
    isSaved?: number;
    privacyType?: string;
    taggedUser?: any[],
    reloopPost?: any
    reloopCount?: number;
    commentOption?: boolean
    downloadOption?: boolean
    group?: any;
    showInFeeds?: boolean;
    groupPost?: boolean
    verified?: boolean
    encrypt?: string;
    mediaDatatype?: string;
    viewCount?: number;
    shareCount?: number;
    downloadCount?: number;
    Poll?: any[];
    pollDuration?: string;
    isVoted?: number;
    selectedOption?: string;
    goingCount?: number;
    isGoing?: number;
    isDownload?: boolean;
    isComment?: boolean;
    comment?: any[];
    endedAt?: string;
    title?: string;
    date?: number;
    blockedUsers?: any[];
    report?: any[];
    isAdmin?: boolean;
    month?: number;
    year?: number;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const postSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    url: { type: String, default: "" },
    key: { type: String, default: "" },
    fileType: { type: Number },
    textContent: { type: String, default: "" },
    thumbnail: { type: String },
    postType: { type: Number, default: 1 },
    body: { type: String },
    user: { type: mongoose.Types.ObjectId, ref: "User" },
    likeCount: { type: Number, default: 0 },
    commentCount: { type: Number, default: 0 },
    hashtag: { type: Array },
    place: { type: String, default: "" },
    category: { type: mongoose.Types.ObjectId, ref: "Category" },
    categoryName: { type: String },
    isActive: { type: Boolean, default: true },
    isLiked: { type: Number, default: 0 },
    isSaved: { type: Number, default: 0 },
    privacyType: { type: String, default: "" },
    taggedUser: [{ type: mongoose.Types.ObjectId, ref: "User" }],
    reloopPost: { type: mongoose.Types.ObjectId, ref: "Posts" },
    reloopCount: { type: Number, default: 0 },
    commentOption: { type: Boolean, default: true },
    downloadOption: { type: Boolean, default: true },
    group: { type: mongoose.Types.ObjectId, ref: "groups" },
    showInFeeds: { type: Boolean, default: true },
    groupPost: { type: Boolean, default: false },
    isDownload: { type: Boolean, default: false },
    isBid: { type: Boolean, default: false },
    bidingCount: { type: Number, default: 0 },
    bidAmount: { type: Number, default: 0 },
    isBided: { type: Boolean, default: false },
    bidedUser: { type: mongoose.Types.ObjectId, ref: "User" },
    isComment: { type: Boolean, default: false },
    verified: { type: Boolean, default: true },
    encrypt: { type: String, default: "" },
    mediaDatatype: { type: String, default: "" },
    viewCount: { type: Number, default: 0 },
    shareCount: { type: Number, default: 0 },
    downloadCount: { type: Number, default: 0 },
    Poll: [{
        option: { type: String, default: "" },
        vote: { type: Number, default: 0 }
    }],
    comment: [
        {
            user: { type: mongoose.Types.ObjectId, ref: 'User' },
            comments: { type: String, default: "" },
            createdOn: { type: Date },
            like: [{ type: mongoose.Types.ObjectId, ref: 'User' }],
            replay: [
                {
                    user: { type: mongoose.Types.ObjectId, ref: 'User' },
                    comments: { type: String, default: "" },
                    like: [{ type: mongoose.Types.ObjectId, ref: 'User' }]
                }
            ]
        }
    ],
    pollDuration: { type: String, default: "" },
    isVoted: { type: Number, default: 0 },
    selectedOption: { type: String, default: "" },
    goingCount: { type: Number, default: 0 },
    isGoing: { type: Number, default: 0 },
    endedAt: { type: String, default: "" },
    title: { type: String, default: "" },
    blockedUsers: [{
        type: mongoose.Types.ObjectId, ref: 'User'
    }],
    report: [{
        type: { type: String },
        user: { type: mongoose.Types.ObjectId, ref: 'User' },
        description: { type: String },
        createdOn:{type:Date}
    }],
    isAdmin: { type: Boolean, default: false },
    date: { type: Number },
    month: { type: Number },
    year: { type: Number },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Post = mongoose.model('Post', postSchema);
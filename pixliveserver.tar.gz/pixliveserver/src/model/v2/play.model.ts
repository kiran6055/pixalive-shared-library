import mongoose from 'mongoose'

export interface PlayDocument extends mongoose.Document {
    _id?: any;
    url?: string;
    key?: string;
    coverImageUrl?: string;
    user?: any;
    description?: string;
    likedUser?: any[];
    taggedUser?: any[];
    likeCount?: number;
    commentCount?: number;
    shareCount?: number;
    isLiked?: number;
    isActive?: boolean;
    isDownload?: boolean;
    isBid?: boolean;
    bidAmount?: number;
    isBided?:boolean;
    bidedUser?: any;
    playType?:number;
    blockedUsers?: any[];
    viewedCount?: number;
    viewed?: number;
    comment?:[];
    report?: any[];
    isAdmin?: boolean;
    isDeleted?: boolean;
    status?: number;
    date?: number;
    month?: number;
    year?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const playSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    url: { type: String, default: '' },
    key:{ type: String, default: '' },
    coverImageUrl: { type: String, default: '' },
    coverImageKey: { type: String, default: '' },
    description: { type: String, default: "" },
    user: { type: mongoose.Types.ObjectId, ref: "User" },
    likedUser: [{ type: mongoose.Types.ObjectId, ref: "user" }],
    taggedUser: [{ type: mongoose.Types.ObjectId, ref: "User" }],
    likeCount: { type: Number, default: 0 },
    commentCount: { type: Number, default: 0 },
    shareCount: { type: Number, default: 0 },
    isLiked: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true, },
    isDownload: { type: Boolean, default: false },
    isBid: { type: Boolean, default: false },
    bidingCount: { type: Number, default: 0 },
    bidAmount: { type: Number, default: 0 },
    isBided: { type: Boolean, default: false },
    bidedUser: { type: mongoose.Types.ObjectId, ref: "User" },
    playType: { type: Number,default:1 },
    viewedCount: { type: Number, default: 0 },
    viewedUser:[{ type: mongoose.Types.ObjectId, ref: "User" }],
    viewed: { type: Number, default: 0 },
    isAdmin: { type: Boolean, default: false },
    date: { type: Number },
    comment: [
        {
            user: { type: mongoose.Types.ObjectId, ref: 'User' },
            comments: { type: String, default: "" },
            createdOn:{type:Date},
            like: [{ type: mongoose.Types.ObjectId, ref: 'User' }],
            replay: [
                {                    user: { type: mongoose.Types.ObjectId, ref: 'User' },
                    comments: { type: String, default: "" },
                    like: [{ type: mongoose.Types.ObjectId, ref: 'User' }]
                }
            ]
        }
    ],
    blockedUsers: [{
        type: mongoose.Types.ObjectId, ref: 'User'
    }],
    report: [{
        type: { type: String },
        user: { type: mongoose.Types.ObjectId, ref: 'User' },
        description: { type: String },
        createdOn:{type:Date}
    }],
    month: { type: Number },
    year: { type: Number },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Play = mongoose.model('Play', playSchema);
import mongoose from 'mongoose'

export interface CategoryDocument extends mongoose.Document {
    _id?: any;
    category?: string;
    image?: string;
    fileName?:string;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const categorySchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    category: { type: String },
    image: { type: String },
    fileName:{type:String},
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Category = mongoose.model('Category', categorySchema);
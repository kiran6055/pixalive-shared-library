import mongoose from 'mongoose'

export interface LikesDocument extends mongoose.Document {
    _id?: any;
    post?: any;
    user?: any;
    isLike?: number;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const likesSchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    post: { type: mongoose.Types.ObjectId, ref: "Post" },
    user: { type: mongoose.Types.ObjectId, ref: "User" },
    isLike: { type: Number, default: 0 },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const Likes = mongoose.model('Likes', likesSchema);
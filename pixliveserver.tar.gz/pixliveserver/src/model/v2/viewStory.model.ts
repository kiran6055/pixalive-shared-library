import mongoose from 'mongoose'

export interface ViewStoryDocument extends mongoose.Document {
    _id?: any;
    story?: any;
    viewedUser?: any;
    isDeleted?: boolean;
    status?: number;
    modifiedOn?: Date;
    modifiedBy?: string;
    createdOn?: Date;
    createdBy?: string;
};

const viewStorySchema = new mongoose.Schema({
    _id: { type: mongoose.Types.ObjectId, required: true, auto: true },
    story: { type: mongoose.Types.ObjectId, ref: "Story" },
    viewedUser: { type: mongoose.Types.ObjectId, ref: "User" },
    isDeleted: { type: Boolean, default: false },
    status: { type: Number, default: 1 },
    modifiedOn: { type: Date },
    modifiedBy: { type: String },
    createdOn: { type: Date },
    createdBy: { type: String }
});

export const ViewStory = mongoose.model('ViewStory', viewStorySchema);
import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { deleteCoins, getAllCoins, getFilterAdminCoins, getSingleCoins, saveCoins, updateCoins } from '../../controller/v2/coins.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllCoins);

router.post('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('title'),
    saveCoins);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateCoins);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteCoins);

router.get('/getSingleCoins',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleCoins);

router.put('/getFilterAdminCoins',
    basicAuthUser,
    checkSession,
    getFilterAdminCoins);

    
export default router
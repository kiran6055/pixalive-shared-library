import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { deleteSlider, getAllSliderByLogOut, getAllSlider, getFilterSlider, getSingleSlider, saveSlider, updateSlider } from '../../controller/v2/slider.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllSlider);

router.post('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('imageUrl'),
    saveSlider);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateSlider);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteSlider);

router.get('/getSingleCategory',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleSlider);

router.put('/getFilterSlider',
    basicAuthUser,
    checkSession,
    getFilterSlider);

    router.get('/getAllSliderByLogOut',
    basicAuthUser,
    getAllSliderByLogOut);

export default router
import { Router } from 'express';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { getChartDetails, getDashboardDetails, getRecentUserAndPost } from '../../controller/v2/dashboard.controller';
const router: Router = Router();


router.get('/',
    basicAuthUser,
    checkSession,
    getDashboardDetails);

router.get('/getRecentUserAndPost',
    basicAuthUser,
    checkSession,
    getRecentUserAndPost);

router.get('/getChartDetails',
    basicAuthUser,
    checkSession,
    getChartDetails);


export default router;
import { Router } from 'express';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { checkRequestBodyParams } from '../../middleware/Validators';
import { loginUser, resentOTP, verifyLoginOtp } from '../../controller/v2/login.controller';
const router: Router = Router();

router.post('/',
    basicAuthUser,
    checkRequestBodyParams('phone'),
    loginUser
);

router.post('/verifyOtp',
    basicAuthUser,
    checkRequestBodyParams('_id'),
    checkRequestBodyParams('otp'),
    verifyLoginOtp);

    router.put('/resentOtp',
    basicAuthUser,
    checkRequestBodyParams('_id'),
    resentOTP);

export default router
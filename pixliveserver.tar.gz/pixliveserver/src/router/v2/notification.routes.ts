import { Router } from 'express';
import { deleteNotification, getAllNotification, getFilterNotification, getFilterNotificationApp, getSingleNotification, saveNotification, sendPushNotification } from '../../controller/v2/notification.controller';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
const router: Router = Router();

router.post('/sendPushNotification',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('title'),
    checkRequestBodyParams('message'),
    sendPushNotification);

router.get('/',
    basicAuthUser,
    checkSession,
    getAllNotification);

router.post('/',
    basicAuthUser,
    checkSession,
    saveNotification);

// router.put('/',
//     basicAuthUser,
//     checkSession,
//     checkRequestBodyParams('_id'),
//     updateNotification);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteNotification);

router.get('/getSingleNotification',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleNotification);

router.put('/getFilterNotification',
    basicAuthUser,
    checkSession,
    getFilterNotification);

router.put('/getFilterNotificationApp',
    basicAuthUser,
    checkSession,
    getFilterNotificationApp);


export default router;
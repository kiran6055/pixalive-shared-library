import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { deleteFollowers, acceptFollower, getAllFollowing, getRequestFollower, getfollowerList, getfollowingList, saveFollower, getfolloweFilter, getFollowingFilter } from '../../controller/v2/folllowing.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    checkQuery('id'),
    getAllFollowing);

router.post('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('follower'),
    checkRequestBodyParams('following'),
    saveFollower);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    acceptFollower);


router.get('/getfollowerList',
    basicAuthUser,
    checkSession,
    checkQuery('id'),
    getfollowerList);

router.get('/getfollowingList',
    basicAuthUser,
    checkSession,
    checkQuery('id'),
    getfollowingList);

router.put('/getfolloweFilter',
    basicAuthUser,
    checkSession,
    getfolloweFilter);

router.put('/getFollowingFilter',
    basicAuthUser,
    checkSession,
    getFollowingFilter);


router.get('/getRequestFollower',
    basicAuthUser,
    checkSession,
    checkQuery('id'),
    getRequestFollower);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('id'),
    deleteFollowers);


export default router
import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { createPlayComments, deletePlay, deletePlayComments, getAllPlay, getFilterAdminPlay, getFilterBidPlay, getFilterPlay, getFilterPlayForWebApp, getFilterPlayForWebAppByLogOut, getPlayComments, getSinglePlay, getTrendingVideos, playBlockByUser, savePlay, savePlayLikes, updatePlayBlockUsers, updatePlay, updatePlayReport, updateViewedUser, getFilterPlayReportForWeb, getSinglePlayForShare, updatePlayActiveStatus } from '../../controller/v2/play.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllPlay);

router.post('/',
    basicAuthUser,
    checkSession,
    savePlay);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updatePlay);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deletePlay);

router.get('/getSinglePlay',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSinglePlay);

router.put('/getFilterPlay',
    basicAuthUser,
    checkSession,
    getFilterPlay);


router.post('/savePlayLikes',
    basicAuthUser,
    checkSession,
    savePlayLikes);

router.put('/getFilterAdminPlay',
    basicAuthUser,
    checkSession,
    getFilterAdminPlay);

router.put('/getFilterPlayForWebApp',
    basicAuthUser,
    checkSession,
    getFilterPlayForWebApp);

router.put('/getFilterPlayForWebAppByLogOut',
    basicAuthUser,
    getFilterPlayForWebAppByLogOut
);

router.put('/getTrendingVideos',
    basicAuthUser,
    checkSession,
    getTrendingVideos);

router.put('/getFilterBidPlay',
    basicAuthUser,
    checkSession,
    getFilterBidPlay);

router.put('/updateViewedUser',
    basicAuthUser,
    checkSession,
    updateViewedUser);

router.post('/createPlayComments',
    basicAuthUser,
    checkSession,
    createPlayComments)


router.get('/getPlayComments',
    basicAuthUser,
    checkSession,
    getPlayComments)

router.put('/deletePlayComments',
    basicAuthUser,
    checkSession,
    deletePlayComments)

router.put('/playBlockByUser',
    basicAuthUser,
    checkSession,
    playBlockByUser)

router.put('/updatePlayReport',
    basicAuthUser,
    checkSession,
    updatePlayReport)

router.put('/updatePlayBlockUsers',
    basicAuthUser,
    checkSession,
    updatePlayBlockUsers)

    router.put('/getFilterPlayReport',
    basicAuthUser,
    checkSession,
    getFilterPlayReportForWeb);

    router.get('/getSinglePlayForShare',
    basicAuthUser,
    getSinglePlayForShare);

    router.put('/updatePlayActiveStatus',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updatePlayActiveStatus);

export default router
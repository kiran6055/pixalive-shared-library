import { Router } from 'express';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { adminLogin, forgotPassword, getSingleAdminProfile, getSingleAdminUser, resetPassword, updateAdminPassword, updateAdminProfile } from '../../controller/v2/adminLogin.controller';
import { checkSession } from '../../utils/tokenManager';
const router: Router = Router();

router.post('/',
    basicAuthUser,
    checkRequestBodyParams('email'),
    checkRequestBodyParams('password'),
    adminLogin);

router.put('/forgotPassword',
    basicAuthUser,
    checkRequestBodyParams('email'),
    forgotPassword);


router.put('/resetPassword',
    basicAuthUser,
    checkRequestBodyParams('_id'),
    checkRequestBodyParams('password'),
    resetPassword);

    router.put('/updateAdminProfile',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateAdminProfile);

    router.get('/getSingleAdminUser',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleAdminUser);

    router.get('/getSingleAdminProfile',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleAdminProfile);

    router.put('/updatePassword',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateAdminPassword);


export default router;
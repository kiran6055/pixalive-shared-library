import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { getSingleSettings, updateSettings } from '../../controller/v2/settings.controller';
const router: Router = Router();

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('title'),
    updateSettings);

    router.get('/',
    basicAuthUser,
    checkSession,
    checkQuery('title'),
    getSingleSettings);

export default router
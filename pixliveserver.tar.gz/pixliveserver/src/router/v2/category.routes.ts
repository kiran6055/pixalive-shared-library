import { Router } from 'express';
import { deleteCategory, getAllCategory, getFilterAdminCategory, getFollowCategoryDetails, getSingleCategory, getTrendingCategories, saveCategory, updateCategory } from '../../controller/v2/category.controller';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
const router: Router = Router();

router.get('/',
    // basicAuthUser,
    // checkSession,
    getAllCategory);

router.post('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('category'),
    saveCategory);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateCategory);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteCategory);

router.get('/getSingleCategory',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleCategory);

router.put('/getFilterAdminCategory',
    basicAuthUser,
    checkSession,
    getFilterAdminCategory);

    router.get('/getFollowCategoryDetails',
    basicAuthUser,
    checkSession,
    getFollowCategoryDetails);

    router.get('/getTrendingCategories',
    basicAuthUser,
    checkSession,
    getTrendingCategories);

export default router
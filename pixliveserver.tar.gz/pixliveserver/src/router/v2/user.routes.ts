import { Router } from 'express';
import { convertoBusiness, deleteUser, getAllUsers, getAllUsersForSearch, getAllUsersFromAdmin, getFilterSuggestionUsersList, getFilterTrendingUsersForWeb, getFilterTrendingUsersFromAdmin, getFilterUsers, getFilterUsersFromAdmin, getSingleUser, getSingleUserForShare, getSuggestionUsersList, getSuggestionUsersListByLogOut, getTrendingUsers, getTrendingUsersByLogOut, getUser, getUserDetails, getUserReferralList, getUserTest, removeBlockUsers, saveUser, saveUserWithOutOtp, updateBlockUsers, updateFCMToken, updateUser, updateUserActiveStatus, updateUserCategory, updateUserFromAdmin, updateUserImage, updateUserRank, verifyOtp } from '../../controller/v2/user.controller';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { sendNotification } from '../../helper/pushNotification';
const router: Router = Router();

router.get('/',
    // basicAuthUser,
    // checkSession,
    getUser);
router.get('/test',
    // basicAuthUser,
    // checkSession,
    getUserTest);


router.get('/getAllUsersFromAdmin',
    basicAuthUser,
    checkSession,
    getAllUsersFromAdmin);

router.post('/',
    basicAuthUser,
    checkRequestBodyParams('phone'),
    saveUser);


router.post('/saveUserWithOutOtp',
    basicAuthUser,
    checkRequestBodyParams('phone'),
    saveUserWithOutOtp);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateUser);

router.put('/updateFCMToken',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateFCMToken);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteUser);

router.get('/getSingleUser',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleUser
);

router.post('/verifyOtp',
    basicAuthUser,
    checkRequestBodyParams('_id'),
    checkRequestBodyParams('otp'),
    verifyOtp)

router.put('/updateUserCategory',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    checkRequestBodyParams('category'),
    updateUserCategory)

router.put('/userfilter',
    basicAuthUser,
    checkSession,
    getFilterUsers)

router.get('/getUserDetails',
    basicAuthUser,
    checkSession,
    getUserDetails
);

router.get('/getSuggestionUsersList',
    basicAuthUser,
    checkSession,
    getSuggestionUsersList
);

router.put('/getFilterSuggestionUsersList',
    basicAuthUser,
    checkSession,
    getFilterSuggestionUsersList
);

router.get('/getTrendingUsers',
    basicAuthUser,
    checkSession,
    getTrendingUsers
);

router.put('/getFilterUsersFromAdmin',
    basicAuthUser,
    checkSession,
    getFilterUsersFromAdmin);

router.put('/getFilterAdminTrendingUsers',
    basicAuthUser,
    checkSession,
    getFilterTrendingUsersFromAdmin);

router.put('/getFilterTrendingUsersForWeb',
    basicAuthUser,
    checkSession,
    getFilterTrendingUsersForWeb);

router.put('/updateUserFromAdmin',
    basicAuthUser,
    checkSession,
    updateUserFromAdmin);

router.put('/updateUserRank',
    basicAuthUser,
    checkSession,
    updateUserRank);

router.put('/updateUserImage',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    checkRequestBodyParams('imageUrl'),
    updateUserImage);

router.get('/getTrendingUsersByLogOut',
    basicAuthUser,
    getTrendingUsersByLogOut
);

router.get('/getSuggestionUsersListByLogOut',
    basicAuthUser,
    getSuggestionUsersListByLogOut
);


router.get('/getUserReferralList',
    basicAuthUser,
    checkSession,
    getUserReferralList
);

router.put('/updateBlockUsers',
    basicAuthUser,
    checkSession,
    updateBlockUsers)

router.put('/removeBlockUsers',
    basicAuthUser,
    checkSession,
    removeBlockUsers)

router.get('/getAllUserForSearch',
    basicAuthUser,
    checkSession,
    getAllUsersForSearch
);

router.get('/getSingleUserForShare',
    basicAuthUser,
    getSingleUserForShare
);

router.put('/updateUserActiveStatus',
basicAuthUser,
checkSession,
checkRequestBodyParams('_id'),
updateUserActiveStatus);

router.post('/convertoBusiness',
basicAuthUser,
checkSession,
convertoBusiness);

export default router;
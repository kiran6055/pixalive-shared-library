import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { deleteLikes, getAllLikes, getFilterLikes, getSingleLikes, saveLikes, updateLikes } from '../../controller/v2/like.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllLikes);

router.post('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('post'),
    checkRequestBodyParams('user'),
    saveLikes);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateLikes);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteLikes);

router.get('/getSingleLikes',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleLikes);

router.put('/getFilterLikes',
    basicAuthUser,
    checkSession,
    getFilterLikes);


export default router
import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { payoutPayment } from '../../controller/v2/payment.controller';

const router: Router = Router();

router.post('/',
    basicAuthUser,
    checkSession,
    payoutPayment);

export default router
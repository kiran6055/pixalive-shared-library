import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { createPostComments, deletePost, deletePostComments, getAllPost, getCategoryBasedPost, getCategoryBasedPostCount, getFilterAdminPost, getFilterBidPost, getFilterPost, getFilterPostForWeb, getOwnPostList, getPostComments, getSinglePost, getUserOwnPostList, postBlockByUser, savePost, updatePostBlockUsers, updatePost, updatePostReport, getFilterPostReportForWeb, getSinglePostForShare, updatePostActiveStatus } from '../../controller/v2/post.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllPost);

router.post('/',
    basicAuthUser,
    checkSession,
    savePost);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updatePost);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deletePost);

router.get('/getSinglePost',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSinglePost);


router.put('/getFilterPost',
    basicAuthUser,
    checkSession,
    getFilterPost);

router.put('/getCategoryBasedPost',
    basicAuthUser,
    checkSession,
    getCategoryBasedPost);

router.put('/getCategoryBasedPostCount',
    basicAuthUser,
    checkSession,
    getCategoryBasedPostCount);

router.put('/getFilterPostForWeb',
    basicAuthUser,
    checkSession,
    getFilterPostForWeb);

router.put('/getFilterBidPost',
    basicAuthUser,
    checkSession,
    getFilterBidPost);


router.put('/getFilterAdminPost',
    basicAuthUser,
    checkSession,
    getFilterAdminPost);

router.get('/getOwnPostList',
    basicAuthUser,
    checkSession,
    getOwnPostList);

router.get('/getUserOwnPostList',
    basicAuthUser,
    checkSession,
    getUserOwnPostList);


router.put('/updatePostBlockUsers',
    basicAuthUser,
    checkSession,
    updatePostBlockUsers)

router.put('/postBlockByUser',
    basicAuthUser,
    checkSession,
    postBlockByUser)

router.post('/createPostComments',
    basicAuthUser,
    checkSession,
    createPostComments)


router.get('/getPostComments',
    basicAuthUser,
    checkSession,
    getPostComments)

router.put('/deletePostComments',
    basicAuthUser,
    checkSession,
    deletePostComments)

router.put('/updatePostReport',
    basicAuthUser,
    checkSession,
    updatePostReport)

router.put('/getFilterPostReport',
    basicAuthUser,
    checkSession,
    getFilterPostReportForWeb);

router.get('/getSinglePostForShare',
    basicAuthUser,
    getSinglePostForShare);

    router.put('/updatePostActiveStatus',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updatePostActiveStatus);


export default router
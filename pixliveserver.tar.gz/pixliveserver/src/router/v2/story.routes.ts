import { Router } from 'express';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
import { deleteStory, getAllStory, getFilterAdminStory, getFilterStory, getFollowingUserStory, getSingleStory, getStoryUser, getUserStory, saveSeenUser, saveStory, updateStory } from '../../controller/v2/story.controller';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllStory);

router.post('/',
    basicAuthUser,
    checkSession,
    saveStory);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateStory);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteStory);

router.get('/getSingleStory',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleStory);

router.put('/getFilterStory',
    basicAuthUser,
    checkSession,
    getFilterStory);


router.put('/getStoryUser',
    basicAuthUser,
    checkSession,
    getStoryUser)

router.put('/getFilterAdminStory',
    basicAuthUser,
    checkSession,
    getFilterAdminStory);


router.get('/getUserStory',
    basicAuthUser,
    checkSession,
    getUserStory);

router.get('/getFollowingUserStory',
    basicAuthUser,
    checkSession,
    getFollowingUserStory);

router.put('/saveSeenUser',
    basicAuthUser,
    checkSession,
    saveSeenUser);



export default router
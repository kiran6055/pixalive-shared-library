import { Router } from 'express';
import { deleteBidding, getAllBidding, getAllBiddingByPlay, getAllBiddingByPost, getFilterBidding, getSingleBidding, saveBidding, updateBiddedUser, updateBidding } from '../../controller/v2/bidding.controller';
import { checkQuery, checkRequestBodyParams } from '../../middleware/Validators';
import { basicAuthUser } from '../../middleware/checkAuth';
import { checkSession } from '../../utils/tokenManager';
const router: Router = Router();

router.get('/',
    basicAuthUser,
    checkSession,
    getAllBidding);

router.post('/',
    basicAuthUser,
    checkSession,
    saveBidding);

router.put('/',
    basicAuthUser,
    checkSession,
    checkRequestBodyParams('_id'),
    updateBidding);

router.delete('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteBidding);

router.get('/getSingleBidding',
    basicAuthUser,
    checkSession,
    getSingleBidding);

router.get('/getAllBiddingByPost',
    basicAuthUser,
    checkSession,
    getAllBiddingByPost);

router.get('/getAllBiddingByPlay',
    basicAuthUser,
    checkSession,
    getAllBiddingByPlay);

router.put('/updateBiddedUser',
    // basicAuthUser,
    // checkSession,
    updateBiddedUser);

router.put('/getFilterBidding',
    basicAuthUser,
    checkSession,
    getFilterBidding);

export default router
import { Router } from "express";
const router: Router = Router();

import User from './user.routes';
import Login from './login.routes';
import Category from './category.routes';
import Likes from './likes.routes';
import Post from './post.routes';
import Story from './story.routes';
import Follow from './follow.routes';
import Play from './paly.routes';
import Admin from'./adminLogin.routes';
import Dashboard from './dashboard.routes';
import Settings from './settings.routes';
import Slider from './slider.routes';
import Notification from './notification.routes';
import Payment from './payment.routes';
import Bidding from './bidding.routes';
import Coins from './coins.routes';

router.use('/user', User);
router.use('/login', Login);
router.use('/category', Category);
router.use('/likes', Likes);
router.use('/post', Post);
router.use('/story', Story);
router.use('/play', Play);
router.use('/follow', Follow);
router.use('/adminLogin', Admin);
router.use('/dashboard',Dashboard);
router.use('/settings',Settings);
router.use('/slider',Slider);
router.use('/notification',Notification);
router.use('/payment',Payment);
router.use('/bidding',Bidding);
router.use('/coins',Coins);
export default router
/**
 * @author Ponjothi S
 * @description Authentication Methods 
 */

var ObjectId = require('mongodb').ObjectID;
import * as auth from 'basic-auth'; 
import * as jwt from 'jsonwebtoken';
import { clientError } from '../helper/ErrorMessage';

export let basicAuthUser = function (req, res, next) {
    var credentials = auth(req);
    console.log('credentials',credentials);
    console.log('process.env.basicAuthUser',process.env.basicAuthUser);
    console.log('process.env.basicAuthKey',process.env.basicAuthKey);
    if (!credentials || credentials.name != process.env.basicAuthUser || credentials.pass != process.env.basicAuthKey) {
        res.setHeader('WWW-Authenticate', 'Basic realm="example"')
        return res.status(401).json({
            success: false,
            statusCode: 499,
            message: clientError.token.unauthRoute,
        });
    } else {
        next();
    }
}
